package exercicio2;

import java.awt.Graphics;

import javax.swing.JPanel;

public class MeuPainel extends JPanel {

	//Atributos
	private int rect1,rect2,rect3,rect4;
	private int oval1,oval2,oval3,oval4;
	
	//Construtor
	public MeuPainel (int rect, int oval) {
		rect1 = rect;
		rect2 = rect;
		rect3 = rect;
		rect4 = rect;
		oval1 = oval;
		oval2 = oval;
		oval3 = oval;
		oval4 = oval;
	}
	
	//GET e SET
	public int getRect1() {
		return rect1;
	}
	public void setRect1(int rect1) {
		this.rect1 = rect1;
	}
	public int getRect2() {
		return rect2;
	}
	public void setRect2(int rect2) {
		this.rect2 = rect2;
	}
	public int getRect3() {
		return rect3;
	}
	public void setRect3(int rect3) {
		this.rect3 = rect3;
	}
	public int getRect4() {
		return rect4;
	}
	public void setRect4(int rect4) {
		this.rect4 = rect4;
	}
	public int getOval1() {
		return oval1;
	}
	public void setOval1(int oval1) {
		this.oval1 = oval1;
	}
	public int getOval2() {
		return oval2;
	}
	public void setOval2(int oval2) {
		this.oval2 = oval2;
	}
	public int getOval3() {
		return oval3;
	}
	public void setOval3(int oval3) {
		this.oval3 = oval3;
	}
	public int getOval4() {
		return oval4;
	}
	public void setOval4(int oval4) {
		this.oval4 = oval4;
	}
	
	

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
	
		
	//Desenha Retangulo
	g.drawRect(rect1, rect2, rect3, rect4);
	//Desenha Elipse
	g.drawOval(oval1, oval2, oval3, oval4);
	
	
	}
}
