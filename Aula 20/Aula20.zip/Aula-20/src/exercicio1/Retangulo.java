package exercicio1;

public class Retangulo extends FiguraGeometrica{

	//Atributos
	private double lado1,lado2;
	
	//Metodos
	public Retangulo(String nome,double lado1,double lado2) {
		super(nome);
		this.lado1 = lado1;
		this.lado2 = lado2;
		}

	@Override
	public double calculaPerimetro() {
		// TODO Auto-generated method stub
		double per = lado1 * lado2;
		return per;
	}

	@Override
	public double calculaArea() {
		// TODO Auto-generated method stub
		double area = lado1 + lado2;
		
		return area;
	}
	
	
	
}
