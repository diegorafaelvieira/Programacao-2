package exercicio1d;

public class Esporte {
	public String nome;
	public int atletas;

	public void informacoes() {
		System.out.println("O esporte " + this.nome + " possui " + this.atletas + " atletas");
	}
}
