package exemplos;

import java.util.LinkedList;
import java.util.Queue;

public class TesteFila {

	public static void main(String[] args) {
		//cria a fila
		Queue<Pessoa> fila = new LinkedList<Pessoa>();
		
		Pessoa p1 = new Pessoa();
		p1.setNome("Maria");
		p1.setIdade(30);
		
		Pessoa p2 = new Pessoa();
		p2.setNome("Marcos");
		p2.setIdade(35);
		
		fila.add(p1);
		fila.add(p2);

		Pessoa temp = fila.poll();
		
		System.out.println(
				temp.getNome() +
				" tem " +
				temp.getIdade());
		
		temp = fila.poll();
		System.out.println(
				temp.getNome() +
				" tem " +
				temp.getIdade());

	}

}

//processo = programa em execu��o
// objeto da classe processo
