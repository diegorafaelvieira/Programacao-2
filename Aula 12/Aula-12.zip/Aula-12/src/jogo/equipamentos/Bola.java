package jogo.equipamentos;

public class Bola {
	private String marca;
	

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}
}
