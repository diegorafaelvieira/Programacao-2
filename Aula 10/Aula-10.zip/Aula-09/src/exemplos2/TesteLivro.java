package exemplos2;

public class TesteLivro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Livro livro1 = new Livro();
		livro1.autor = "Machado de Assis";
		livro1.titulo = "Quincas Borba";
		livro1.imprimir();

	}

}
