package exercicio2;

public class Administrador extends Empregado{

	//Atributos
	private double ajudaDeCusto;
	
	
	//GET e SET
	public double getAjudaDeCusto() {
		return ajudaDeCusto;
	}

	public void setAjudaDeCusto(double ajudaDeCusto) {
		this.ajudaDeCusto = ajudaDeCusto;
	}
	
	
}
