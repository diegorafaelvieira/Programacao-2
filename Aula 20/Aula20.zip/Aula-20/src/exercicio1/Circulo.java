package exercicio1;

public class Circulo extends FiguraGeometrica {

	//Atributos
	private double raio;
	
	//Metodos
	public Circulo(String nome,double raio) {
		super(nome);
		this.raio = raio;
		}
	
	//GET
	public double getCirculo() {
		return this.raio;
		}
	
	

	@Override
	public double calculaPerimetro() {
		// TODO Auto-generated method stub
		double cp = (2*3.14) * raio;
		return cp;
	}
	

	@Override
	public double calculaArea() {
		// TODO Auto-generated method stub
		double ca = 3.14 * Math.pow(raio, 2);
		return ca;
	}

	
}

	
