package exemplos;

public class Livro extends Produto{

	//Atributos
		private String titulo;
		
		//Construtor
		public Livro(int codigo, String titulo) {
			super(codigo);
			this.titulo = titulo;
			//System.out.println("Passou no construtor do Livro");
		}
		
		public void imprimir() {
			super.imprimir();
			System.out.println("T�tulo: " + this.titulo);
		}

		//GET e SET
		public String getTitulo() {
			return titulo;
		}

		public void setTitulo(String titulo) {
			this.titulo = titulo;
		}
}
