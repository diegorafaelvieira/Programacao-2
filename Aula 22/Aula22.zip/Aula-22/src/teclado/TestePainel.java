package teclado;

import javax.swing.JFrame;

public abstract class TestePainel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MeuPanel p = new MeuPanel();
		p.setFocusable(true);
		p.requestFocus();
		
		JFrame f = new JFrame();
		
		f.add(p);
		f.setSize(350, 420);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		f.setResizable(false);

	}

}
