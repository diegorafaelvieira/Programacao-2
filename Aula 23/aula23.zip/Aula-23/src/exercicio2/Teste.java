package exercicio2;

import java.util.ArrayList;
import java.util.Scanner;



public class Teste {
	
	public static void main(String[] args) {

		//Arraylist, Scanner e declara��o de vari�veis;
				ArrayList<Pessoa> pessoas = new ArrayList<Pessoa>();
				Scanner entrada = new Scanner(System.in);
				String cpf, nome, x,y;
				int idade, op;
				
				//Insere pessoas com atributos: cpf,nome e idade;
				try {
					String continua = "s";
					while(continua.equals("s")) {
						System.out.println("-----------------");
						System.out.println("Inserindo pessoa!");
						System.out.println();
						System.out.print("Informe um CPF: ");
						cpf = entrada.nextLine();
						System.out.print("Informe um nome: ");
						nome= entrada.nextLine();
						System.out.print("Informe a idade: ");
						idade = entrada.nextInt();
						Pessoa p = new Pessoa(cpf,nome,idade);
						pessoas.add(p);
						System.out.print("Deseja continuar inserindo pessoas >>> (s)im <<>> (n)�o <<<: ");
						continua = entrada.next().toLowerCase();
						entrada.nextLine();
						}
				
				
				System.out.println();
				System.out.println("Opera��es!!!");
				System.out.println("(1)Remover pessoa por CPF;\n(2)Remover todas as pessoas;\n(3)Mostrar os dados de todos;\n(4)Mostrar dados de uma pessoa pelo CPF;\n(5)Sair;");
				System.out.print("O que deseja fazer: ");
				op = entrada.nextInt();
				
				switch (op) {
				case  1:
					System.out.println();
					System.out.println("Removendo pessoas pelo CPF!");
					System.out.print("Informe o CPF: ");
					x = entrada.next();
					for (int i = 0; i < pessoas.size(); i++) {
							if (pessoas.get(i).getCpf().equals(x)) {
							      pessoas.remove(i);
								}	
							}
					for (int j = 0; j < pessoas.size(); j++) {
							System.out.println("----------------\nCPF: "+pessoas.get(j).getCpf()+"\nNome: "+pessoas.get(j).getNome()+"\nIdade: "+pessoas.get(j).getIdade());
							}
				break;
				case 2: 
					System.out.println();
					System.out.println("Removendo todas as pessoas!");
					pessoas.clear();
					System.out.println("Pessoas removidas!");
				break;	
				case 3:
					System.out.println();
					System.out.println("Mostrando todas as pessoas cadastradas!");
					for (int i = 0; i < pessoas.size(); i++) {
						System.out.println("----------------\nCPF: "+pessoas.get(i).getCpf()+"\nNome: "+pessoas.get(i).getNome()+"\nIdade: "+pessoas.get(i).getIdade());
						}
				break;
				case 4:
					System.out.println();
					System.out.println("Mostrando dados de uma pessoa pelo CPF!");
					System.out.print("Informe o CPF: ");
					y = entrada.next();
					for (int i = 0; i < pessoas.size(); i++) {
						if (pessoas.get(i).getCpf().equals(y)) {
							System.out.println("----------------\nCPF: "+pessoas.get(i).getCpf()+"\nNome: "+pessoas.get(i).getNome()+"\nIdade: "+pessoas.get(i).getIdade());
							}
						}
				break;
				case 5:		
					System.out.println();
					System.out.println("Saindo... Tchau!");
				break;	
				default:
					System.out.println("Opera��o Inv�lida!");
					break;
					}
				} catch (Exception e) {
					System.out.println("Opera��o ou dado inv�lidos! Erro: "+e);
				}
					entrada.close();
			}
		

     
	
	
}
