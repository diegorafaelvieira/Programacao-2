package exercicios;

import java.util.Scanner;

public class Exercicio4 {

	public static void main(String[] args) {
		/*
		 * Dizemos que um n�mero natural (inteiro n�o negativo) � triangular se ele � produto de tr�s
		n�meros naturais consecutivos.
		Por exemplo, 120 � triangular pois 4*5*6 � igual a 120. J� o n�mero 121 n�o � triangular pois n�o
		existem tr�s n�meros naturais consecutivos cujo produto seja igual a 121.
		Dado um n�mero inteiro n�o negativo n informado pelo usu�rio via teclado, crie um programa que
		determine se n � triangular. Imprima a resposta na tela.
		 */
		
	    int n,t;
		
		Scanner leitor = new Scanner(System.in);
		
		
		System.out.print("Informe um n�mero inteiro positivo para verificar se ele � triangular: ");
		n = leitor.nextInt();
		
		
		int i = 1;
		if ( n == i*(i+1)*(i+2)) {
			System.out.print("O valor"+n+" � triangular!");
		} else {
			System.out.print("O valor "+n+" n�o � triangular!");
	    }
	   
	
	}		
	
}
	
