package exemplo;

public class Gato extends Animal{

	//Atributos
	private String cor;
	
	//Metodo
	public Gato(String nome,String cor) {
		super(nome);
		this.cor = cor;	
		}
	
	//GET
	public String getCor() {
		return this.cor;
		}

	@Override
	public void emitirSom() {
		System.out.println("Gato miando!");
			
		}
}
