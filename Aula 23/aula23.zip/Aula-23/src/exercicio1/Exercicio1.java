package exercicio1;

import java.util.ArrayList;

public class Exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Apartamento> edificio = new ArrayList<Apartamento>();
		
		Apartamento a1 = new Apartamento(30,5);
		Apartamento a2 = new Apartamento(144,3);
		Apartamento a3 = new Apartamento(1000,4);
		
		edificio.add(a1);
		edificio.add(a2);
		edificio.add(a3);
		
		
		
		for (int i = 0; i < edificio.size(); i++) {
			System.out.println("==============================");
			System.out.println("N�mero do apartamento: "+edificio.get(i).getNumero());
			System.out.println("Quantidade de comodos: "+edificio.get(i).getComodos());
		}
		
	}

}
