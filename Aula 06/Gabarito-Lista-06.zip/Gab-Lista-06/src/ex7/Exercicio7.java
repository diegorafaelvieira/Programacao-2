package ex7;

import java.util.Scanner;

public class Exercicio7 {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		
		double[] nota = new double[3];
		double[] maximo = {30.0, 30.0, 40.0};

		for (int i = 0; i < nota.length; i++) {
			boolean notaOK = false;
			do {
				System.out.print("Informe a nota " + (i+1) + ": ");
				nota[i] = leitor.nextDouble();			
				if((nota[i] >= 0) && (nota[i] <= maximo[i])) {
					notaOK = true;
				} else {
					System.out.println("Nota fora da faixa de valores desejada (0.0 a " + maximo[i] + ").");
				}
			} while(!notaOK);
		}
		
		double soma = 0;
		for (int i = 0; i < nota.length; i++) {
			soma += nota[i];
		}
		
		if(soma >= 60) {
			System.out.println("Aluno aprovado com nota " + soma + ".");
		} else {
			System.out.println("Aluno reprovado com nota " + soma + ".");
		}
		
		leitor.close();
	}
}
