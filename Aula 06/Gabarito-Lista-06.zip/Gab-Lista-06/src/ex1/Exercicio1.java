package ex1;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {

		Scanner leitor = new Scanner(System.in);		

		double[][] notas = new double[5][3]; 
		String[] nomes = new String[5];
				
		for (int i = 0; i < 5; i++) {
			System.out.print("Digite o nome do aluno " + (i+1) + ": ");
			nomes[i] = leitor.next();
		
			for (int j = 0; j < 3; j++) {
				System.out.print("Digite a nota " + (j+1) + " do aluno " + nomes[i] + ": ");
				notas[i][j] = leitor.nextDouble();
			}
		}
		
		System.out.println("-------------");
		
		for (int i = 0; i < 5; i++) {
			double soma = 0;
			for (int j = 0; j < 3; j++) {
				soma = soma + notas[i][j];
			}
			double media = soma / 3;
			System.out.println("O aluno " + nomes[i] + " teve media " + media);
		}
		
		System.out.println("-------------");

		for (int j = 0; j < 3; j++) {
			double soma = 0;
			for (int i = 0; i < 5; i++) {
				soma = soma + notas[i][j];
			}
			double media = soma / 5;
			System.out.println("A media na avaliacao " + (j+1) + " foi " + media);
		}		
		
		leitor.close();
	}
}
