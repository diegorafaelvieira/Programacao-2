package gui;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class MeuPainel extends JPanel {

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		// codigo a mais....
		
	
		g.drawLine(100, 100, 300, 300);
		g.drawLine(200, 300, 200, 400);
		
		/* Sem preenchimento "draw"
		//Desenha Retangulo
		g.drawRect(20, 20, 250, 100);
		//Desenha Elipse
		g.drawOval(50, 50, 280, 300);
		*/
		
		// Criar Cor especifica
		Color c1 = new Color(20,70,175);
		Color c2 = new Color(200,200,0);

		
		// com preenchimento "fill"
		g.setColor(c1);
		/*Escrever texto
	    g.drawString("Texto outra cor", 10, 150); */
		g.fillRect(20, 20, 250, 100);
		g.setColor(Color.RED);
		g.fillOval(50, 50, 280, 300);
		
		g.setColor(c1);
		g.drawString("texto em outra cor", 10, 150);
		g.setColor(Color.WHITE);
		g.drawString("Texto em preto", 10, 50);
		
	}
	
}
