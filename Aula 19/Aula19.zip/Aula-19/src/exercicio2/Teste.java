package exercicio2;

import java.util.Scanner;


public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner leitor = new Scanner(System.in);
		
		String nome;
		String cor = null;  // Inseri o null
		double valor;
		valor = 0;
		int tamanho;
		tamanho = 0;

		System.out.print("Informe o nome do produto:");
		nome = leitor.next();
		if (nome.equals("camiseta")) {
		System.out.print("Informe o valor da camiseta:");
		valor = leitor.nextDouble();
		System.out.print("Informe a cor da camiseta:");
		cor = leitor.next();
		Camiseta c1 = new Camiseta(nome,valor,cor);
		System.out.println("Produto: " + c1.getNome());
		System.out.println("Valor: " + c1.getValor());
		System.out.print("Cor: " + c1.getCor());
		} else if (nome.equals("sapato")) {
			System.out.print("Informe o valor do sapato:");
			valor = leitor.nextDouble();
			System.out.print("Informe o tamanho do sapato:");
			tamanho  = leitor.nextInt();
			Sapato s1 = new Sapato(nome,valor,tamanho);
			System.out.println("Produto: " + s1.getNome());
			System.out.println("Valor: " + s1.getValor());
			System.out.print("Tamanho: " + s1.getTamanho());
		} else {
			System.out.println("Produto n�o encontrado!");
		}
		 
		/*
		Comprador comp = new Comprador();
		comp.consulta(p);
		*/
		

		
		leitor.close();
	}


}
