package exercicio1;

public class TesteVeiculos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bicicleta bc = new Bicicleta();
		bc.setMarca ("Caloi");
		System.out.println(bc.getMarca());
		bc.setModelo("bmx");
		System.out.println(bc.getModelo());
		bc.setCor("Verde");
		System.out.println(bc.getCor());
		bc.setQtdMarchas(18);
		System.out.println(bc.getQtdMarchas());
		
		System.out.println("");
		
		Carro car = new Carro();
		car.setMarca("VW");
		System.out.println(car.getMarca());
		car.setModelo("Gol");
		System.out.println(car.getModelo());
		car.setPlaca("IHT-7777");
		System.out.println(car.getPlaca());
		car.setKm(150000);
		System.out.println(car.getKm());
		
		

	}

}
