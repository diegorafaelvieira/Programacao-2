package exercicio1b;

public class TesteBebida {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bebida bebida1 = new Bebida();
		bebida1.tipo = "cerveja";
		bebida1.marca = "Duff";
		bebida1.preco = 5.50;
		
		
		bebida1.informacoes();
	}

}
