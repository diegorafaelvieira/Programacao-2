package exercicio3;

public class TesteBanda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Guitarrista c = new Guitarrista ();
		c.setNome("Peter Townsend");
		c.setIdade(72);
		c.setAnosExperiencia(50);
		c.setInstrumento("Guitarra");
		c.setMarcaGuitarra("Fender");
		System.out.println(c.getNome() + " tem " + c.getIdade() + " anos e toca " + c.getInstrumento() +" "+ c.getMarcaGuitarra() +" " + c.getAnosExperiencia() + " anos de experi�ncia.");
	}

}
