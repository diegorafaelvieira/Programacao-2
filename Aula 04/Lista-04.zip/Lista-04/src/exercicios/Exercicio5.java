package exercicios;

import java.util.Scanner;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.CloseAction;



public class Exercicio5 {

	public static void main(String[] args) {
		/*
		 * 5. Crie um programa Java que:
		a) Leia 5 valores inteiros do teclado e armazene-os em um array.
		b) Ap�s armazenar os valores no array, fa�a a contagem de quantos valores s�o negativos,
			e imprima o resultado da contagem na tela.
		c) Finalmente, imprima os valores positivos na tela.
		 */
		
		
        Scanner leitor = new Scanner(System.in);
        
        int contP = 0;
        int contN = 0;
        int[] valores = {44,12,23,12,17};
        
        for (int i = 0; i < valores.length; i++) {
			if(i > 0)
				contP++;
			else
				if(i < 0) {
					contN++;
				}
		}
        
        leitor.close();
        
        System.out.println("Positivos:" + contP);
        System.out.println("Negativos:" + contN);
        		
        
	}

}
