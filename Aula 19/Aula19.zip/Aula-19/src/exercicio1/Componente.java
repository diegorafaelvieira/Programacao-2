package exercicio1;

public class Componente {

	//Atributos
		private String fabricante;
		private String modelo;
		
		//Construtor
		public Componente(String fabricante, String modelo) {
			this.fabricante = fabricante;
			this.modelo = modelo;
		}
		
		public void imprimir() {
			
			System.out.println("fabricante: " + this.fabricante);
			System.out.println("modelo: " + this.modelo);
		}

		//GET e SET
		public String getFabricante() {
			return fabricante;
		}

		public void setFabricante(String fabricante) {
			this.fabricante = fabricante;
		}

		public String getModelo() {
			return modelo;
		}

		public void setModelo(String modelo) {
			this.modelo = modelo;
		}
		
}
