package exemplo;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Animal a1 = new Cachorro("Cachorro Brabo","Pastor Alem�o");
		
		Cachorro c1 = new Cachorro("Bob","Vira lata");
	
		Gato g1 = new Gato("Chico","Cinza");
		
		//c1.emitirSom();
		//g1.emitirSom();
		
		Animal[] zoo = new Animal[3];
		zoo[0] = new Gato("Pepe","Preto");
		zoo[1] = g1;
		zoo[2] = c1;
		
		for (int i = 0; i < zoo.length; i++) {
			zoo[i].emitirSom();
		}
	}

}
