package exemplos;

import java.util.Scanner;

public class TesteCapturaExceptions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] numeros = new int[2];
		numeros[0] = 10;
		numeros[1] = 20;
		
		Scanner leitor = new Scanner(System.in);
		System.out.print("Informe um indice: ");
		int i = -1;
		
		//int i = leitor.nextInt();
		
		try {
			i = leitor.nextInt();
		} catch (Exception e) {
			System.out.println("Informe apenas n�meros!");
			//Exibe dados do erro para fins de debug
		    //e.printStackTrace();
		}
		
		try {
			System.out.println(numeros[i]);
		} catch(Exception e) {
			System.out.println("Indice inv�lido!");
		}
		
		
		
		leitor.close();
	}

}
