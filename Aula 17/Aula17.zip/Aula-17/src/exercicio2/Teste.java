package exercicio2;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Fornecedor f1 = new Fornecedor();
		f1.setNome("Diego Rafael");
		f1.setEmail("diegorafaelvieira@bol.com.br");
		f1.setTelefone(36353126);
		f1.setValorCredito(20500);
		f1.setValorDivida(5000);
		System.out.println("O fornecedor "+ f1.getNome() + ", possui o email " + f1.getEmail() + " ,o seu telefone de contato � " + 
		f1.getTelefone() + " e possui saldo de R$ " + f1.obterSaldo());
		
		System.out.println("");
		
		
		Empregado e1 =  new Empregado();
		e1.setNome("Z�");
		e1.setEmail("ze@gmail.com");
		e1.setTelefone(36350000);
		e1.setCodigoSetor(11);
		e1.setSalarioBase(1200);
		e1.setImposto(150.50);
	    e1.calcularSalario();
	    System.out.println("O empregado de nome " + e1.getNome() + ", possui o email " + e1.getEmail() + " ,o seu telefone de contato � " +
	    e1.getTelefone() + " ,trabalha no setor " + e1.getCodigoSetor() + " e recebe o sal�rio de R$ " + e1.calcularSalario());
	    
	    System.out.println("");
	    
	    Administrador a1 = new Administrador();
	    a1.setNome("Regina");
	    a1.setEmail("reginaadm@gmail.com");
	    a1.setTelefone(36350108);
	    a1.setCodigoSetor(10);
	    a1.setSalarioBase(5000);
	    a1.setImposto(200.50);
	    a1.setAjudaDeCusto(1000.50);
	    a1.calcularSalario();
	    System.out.println("Quem administra � " + a1.getNome() + ", possui o email " + a1.getEmail() + " ,o seu telefone de contato � " +
	    a1.getTelefone() + " , trabalha no setor " + a1.getCodigoSetor() + " e recebe o sal�rio de R$ " + a1.calcularSalario() + 
	    " mais ajuda de custo no valor de R$ " + a1.getAjudaDeCusto()); 
	    
	    System.out.println("");
	    
	    Operario o1 = new Operario();
	    o1.setNome("Amanda");
	    o1.setEmail("amandaop@gmail.com");
	    o1.setTelefone(36350707);
	    o1.setCodigoSetor(12);
	    o1.setSalarioBase(1200);
	    o1.setImposto(150.50);
	    o1.setValorProducao(10);
	    o1.setComissao(2);
	    o1.calcularSalario();
	    System.out.println("O oper�rio se chama " + o1.getNome() + ", possui o email " + o1.getEmail() + " ,o seu telefone de contato � " +
	    	    o1.getTelefone() + " , trabalha no setor " + o1.getCodigoSetor() + " e recebe o sal�rio de R$ " + o1.calcularSalario() + 
	    	    " recebe o valor de produ��o de R$ " + o1.getValorProducao() + " e mais o valor da comiss�o de  " + o1.getComissao() + " %");
	
	    System.out.println("");
	    
	    Vendedor v1 = new Vendedor();
	    v1.setNome("Jo�o");
	    v1.setEmail("joaovendas@gmail.com");
	    v1.setTelefone(36351504);
	    v1.setCodigoSetor(13);
	    v1.setSalarioBase(2000.99);
	    v1.setImposto(150.50);
	    v1.setValorVendas(100);
	    v1.setComiss�o(3);
	    v1.calcularSalario();
	    System.out.println("O vendedor se chama " + v1.getNome() + ", possui o email " + v1.getEmail() + " ,o seu telefone de contato � " +
	    	    v1.getTelefone() + " , trabalha no setor " + v1.getCodigoSetor() + " e recebe o sal�rio de R$ " + v1.calcularSalario() + 
	    	    " , realizou " + v1.getValorVendas() +" vendas " + " e recebe  comiss�o de  " + v1.getComiss�o() + " %");
	}
	
	
}
