package exemplos;

public class TesteEstatico {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println(Contador.numero);
		Contador.numero = 10;
		System.out.println(Contador.numero);
		Contador.numero = 20;
		System.out.println(Contador.numero);
		
		//Criou objeto da classe
		Contador c = new Contador();
		c.numero = 30;
		System.out.println(c.numero);
		
		
		// adiciona mais um a cada objeto criado
		Contador c1 = new Contador();
		System.out.println(c1.numero);
		
		Contador c2 = new Contador();
		System.out.println(c2.numero);
		
	}

}
