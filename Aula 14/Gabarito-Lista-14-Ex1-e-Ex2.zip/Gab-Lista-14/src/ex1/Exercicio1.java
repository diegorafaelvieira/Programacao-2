package ex1;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		Carro[] frota = new Carro[3];
		Scanner leitor = new Scanner(System.in);
		
		for (int i = 0; i < frota.length; i++) {
			System.out.print("Modelo: ");
			String modelo = leitor.nextLine();
			System.out.print("Marca: ");
			String marca = leitor.nextLine();
			System.out.print("Placa: ");
			String placa = leitor.nextLine();
			frota[i] = new Carro(marca,modelo,placa);
		}
		
		for (int i = 0; i < frota.length; i++) {
			System.out.println(frota[i].getMarca() + " " +
					frota[i].getModelo() + " " + 
					frota[i].getPlaca());
		}	
		
		
		leitor.close();

	}

}
