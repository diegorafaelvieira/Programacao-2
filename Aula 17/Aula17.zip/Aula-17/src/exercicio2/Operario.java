package exercicio2;

public class Operario extends Empregado{

	//Atributos
	private double valorProducao;
	private double comissao;
	
	//GET e SET
	public double getValorProducao() {
		return valorProducao;
	}
	public void setValorProducao(double valorProducao) {
		this.valorProducao = valorProducao;
	}
	public double getComissao() {
		return comissao;
	}
	public void setComissao(double comissao) {
		this.comissao = comissao;
	}
	
	
}
