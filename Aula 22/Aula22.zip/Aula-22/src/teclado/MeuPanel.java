package teclado;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.JPanel;

public class MeuPanel extends JPanel implements KeyListener {

	private int x = 100;
	private int y = 100;
	
	public MeuPanel() {
		super();
		addKeyListener(this);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		//System.out.println("KeyTyped: " + e.getKeyCode());
		
		int tecla = e.getKeyCode();
		//Esquerda
		if(tecla == 37) {
			x = x -50;
			g.drawRect(x, y, 50, 50);
			this.repaint();
		}
		//Subir
		if (tecla == 38) {
			Random r = new Random();
			int x = r.nextInt(400);
			int y = r.nextInt(400);
			Graphics g = getGraphics();
			g.drawOval(x, y, 100, 100);
		}
		
		if (tecla == KeyEvent.VK_Q) {
			;
			Graphics g = getGraphics();
			g.drawRect(50, 50, 200, 200);
		}
		if (tecla == KeyEvent.VK_C) {
			Random r = new Random();
			int x = r.nextInt(400);
			int y = r.nextInt(400);
			Graphics g = getGraphics();
			g.drawOval(x, y, 100, 100);
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		//System.out.println("KeyReleased: " + e.getKeyCode());
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		//System.out.println("KeyEvent: " + e.getKeyChar());
		
	}
	
}
