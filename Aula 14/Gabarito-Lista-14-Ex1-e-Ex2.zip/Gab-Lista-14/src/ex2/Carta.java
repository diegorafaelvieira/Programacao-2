package ex2;

public class Carta {
	private int naipe;
	private int numero;
	
	public Carta(int naipe, int numero) {
		this.naipe = naipe;
		this.numero = numero;
	}

	public String getNaipe() {
		switch(naipe) {
			case 0: return "Ouros";
			case 1: return "Espadas";
			case 2: return "Copas";
			case 3: return "Bastos";
		}
		return null;
	}

	public String getNumero() {
		int numeroMaisUm = numero+1;
		
		switch(numeroMaisUm) {
			case 1: return "As";
			case 11: return "Valete";
			case 12: return "Rainha";
			case 13: return "Rei";
		}
		
		return String.valueOf(numeroMaisUm);
	}
}
