package exercicio2;

public class Vendedor extends Empregado {

	//Atruibutos
	private double valorVendas;
	private double comiss�o;
	
	//GET e SET
	public double getValorVendas() {
		return valorVendas;
	}
	public void setValorVendas(double valorVendas) {
		this.valorVendas = valorVendas;
	}
	public double getComiss�o() {
		return comiss�o;
	}
	public void setComiss�o(double comiss�o) {
		this.comiss�o = comiss�o;
	}
	
	
}
