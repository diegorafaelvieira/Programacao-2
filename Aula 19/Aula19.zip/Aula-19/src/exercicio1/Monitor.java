package exercicio1;

public class Monitor extends Componente{

	//Atributos
		private String resolucao;
		
		
		//Construtor
		public Monitor(String fabricante, String modelo ,String resolucao) {
			super(fabricante,modelo);
			this.resolucao = resolucao;
		}

		public void imprimir() {
			super.imprimir();
			System.out.println("Resolucao: " + this.resolucao);
		}

		//GET e SET
		public String getResolucao() {
			return resolucao;
		}


		public void setResolucao(String resolucao) {
			this.resolucao = resolucao;
		}
}
