package exemplos;

public class Produto {
	//atributos
	private int codigo;

	//construtor
	public Produto(int codigo) {
		this.codigo = codigo;
	}

	//GET e SET
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	

}
