package exercicio1;

public class Celular {
	public String modelo;
	public String marca;
	
	

}
