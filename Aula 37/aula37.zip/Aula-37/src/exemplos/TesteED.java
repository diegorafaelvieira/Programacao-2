package exemplos;

import java.util.Stack;

public class TesteED {

	public static void main(String[] args) {
		
		//Pilha objetos da classe livro
		Stack<Livro> pilha = new Stack<Livro>();


		Livro l1 = new Livro();
		l1.setAutor("Fulano");
		l1.setTitulo("Java in 21 days");

		Livro l2 = new Livro();
		l2.setAutor("Ciclano");
		l2.setTitulo("Python in 21 days");

		Livro l3 = new Livro();
		l3.setAutor("Beltrano");
		l3.setTitulo("C++ in 21 days");

		//a��es de push na pilha
		pilha.push(l1);
		pilha.push(l2);
		pilha.push(l3);
		
		//! = pilha n�o vazia  //aqui o primeiro vira o �ltimo no print
		while(!pilha.empty()) {
			Livro temp = pilha.pop();
			System.out.println(temp.getAutor() + " "
					+ temp.getTitulo());
		}
	}

}
