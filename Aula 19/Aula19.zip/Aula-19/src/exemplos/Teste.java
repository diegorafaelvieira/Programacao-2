package exemplos;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			
			//123 = c�digo
			Livro l = new Livro(123,"Java em 21 dias");
			l.imprimir();
			
			System.out.println("");
			
			//456 = c�digo - 70=n�m p�ginas  MarcaCaderno=marca
			Caderno c = new Caderno(456,70,"MarcaCaderno");
			c.imprimir();
			
			System.out.println("");
			
			Produto[] prateleira = new Produto[2];
			prateleira[0] = l;
			prateleira[1] = c;
			
			prateleira[0].imprimir();
			prateleira[1].imprimir();

		}

	

}
