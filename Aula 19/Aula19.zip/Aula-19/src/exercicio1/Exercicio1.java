package exercicio1;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner leitor = new Scanner(System.in);
		String x1,x2,x3;
		 
		
		
		System.out.print("Informe o nome do fabricante do monitor:");
		x1 = leitor.next();
		System.out.print("Informe o modelo do monitor:");
		x2 = leitor.next();
		System.out.print("Informe a resolu��o do monitor:");
		x3 = leitor.next();
		
		Monitor m1 = new Monitor(x1,x2,x3);
		System.out.println("Fabricante: " + m1.getFabricante());
		System.out.println("Modelo: " + m1.getModelo());
		System.out.print("Resolu��o: " + m1.getResolucao());
		
		System.out.println();
		
		System.out.print("Informe o nome do fabricante do disco rigido:");
		x1 = leitor.next();
		System.out.print("Informe o modelo do disco rigido:");
		x2 = leitor.next();
		System.out.print("Informe a capacidade do disco r�gido:");
		x3 = leitor.next();
		
		DiscoRigido d1 = new DiscoRigido(x1,x2,x3);
		System.out.println("Fabricante: " + d1.getFabricante());
		System.out.println("Modelo: " + d1.getModelo());
		System.out.println("Capacidade: " + d1.getCapacidade());
		//Comando para inserir um novo fabricante
		System.out.println("Informe um novo Fabricante: ");
		d1.setFabricante(leitor.next());
		System.out.println("O novo fabricante �: " + d1.getFabricante());
		
		leitor.close();
	
	}

}
