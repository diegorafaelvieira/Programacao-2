package exemplos;

import javax.swing.JFrame;

public class TesteCenario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Moldura
		JFrame f = new JFrame();
		//Painel
		Cenario c = new Cenario();
		//Junta Moldura e Painel
		f.add(c);
		f.setSize(350, 420);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		f.setResizable(false);

	}

}
