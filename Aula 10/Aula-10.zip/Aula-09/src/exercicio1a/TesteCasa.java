package exercicio1a;

public class TesteCasa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Casa casa1 = new Casa();
		casa1.cor = "amarela";
		casa1.numero = 30;
		casa1.qtdMoradores = 4;
		
		
		casa1.imprimir();
		

	}

}
