package exercicio3;

public class Musico extends Pessoa{

	//Atributos
	private String instrumento;
	private double anosExperiencia;
	
	
	//GET e SET
	public String getInstrumento() {
		return instrumento;
	}
	public void setInstrumento(String instrumento) {
		this.instrumento = instrumento;
	}
	public double getAnosExperiencia() {
		return anosExperiencia;
	}
	public void setAnosExperiencia(double anosExperiencia) {
		this.anosExperiencia = anosExperiencia;
	}
	

	
	
}
