package arquivos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LeArquivo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File arquivo= new File("Registro/nomes.txt");
		
		//Aqui não vai true ou false
		try {
			FileReader leitor = new FileReader(arquivo);
			BufferedReader buffer = new BufferedReader(leitor);
			
			String linha = null;
			
			while((linha = buffer.readLine()) !=null) {
				System.out.println(linha);
			}
			
			//Não esquecer de fechar
			buffer.close();
			leitor.close();
			
			//Trocar para IOException
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
