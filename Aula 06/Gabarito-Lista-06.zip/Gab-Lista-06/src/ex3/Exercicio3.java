package ex3;

import java.util.Random;

public class Exercicio3 {

	public static void main(String[] args) {
		
		int numeroElementos = 1000;
		int[] lista = new int[numeroElementos];
				
		// Construcao da lista
		for (int i = 0; i < numeroElementos; i++) {
			lista[i] = i;
		}
		
		// Faz o embaralhamento
		int numeroEmbaralhadas = 1000000;
		Random r = new Random();
		for (int j = 0; j < numeroEmbaralhadas; j++) {
			
			// Sorteia 2 posicoes para serem trocadas
			int posicao1 = r.nextInt(numeroElementos);
			int posicao2 = r.nextInt(numeroElementos);

			// Troca os valores das posicoes
			int temp = lista[posicao1];
			lista[posicao1] = lista[posicao2];
			lista[posicao2] = temp;
		}
		
		// Imprime os elementos da lista
		for (int i = 0; i < numeroElementos; i++) {
			System.out.println(lista[i]);
		}
	}

}
