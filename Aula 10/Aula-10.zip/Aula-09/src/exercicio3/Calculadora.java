package exercicio3;

public class Calculadora {
	
	int resultado;
	
	public int soma (int v1 , int v2) {
	
		resultado = v1 + v2;
		return resultado;
	}
	
	public int subtracao (int v1 , int v2) {
		
		resultado = v1 - v2;
		return resultado;
	}
	
	
	public int multiplicacao (int v1, int v2) {
		
		resultado = v1 * v2;
		return resultado;
	}
	
	public int divisao  (int v1, int v2){
		
		resultado = v1 * v2;
		return resultado;
	}
	
	//colocar media
	
	
	


}
