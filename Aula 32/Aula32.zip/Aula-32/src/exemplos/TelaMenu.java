package exemplos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.CardLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaMenu {

	private JFrame frame;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaMenu window = new TelaMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaMenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu mnCadastrar = new JMenu("Cadastrar");
		menuBar.add(mnCadastrar);
		
		JMenuItem mntmPessoa = new JMenuItem("Pessoa");
		mntmPessoa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.setVisible(false);
				panel_1.setVisible(true);
				panel_2.setVisible(false);
			}
		});
		mnCadastrar.add(mntmPessoa);
		
		JMenuItem mntmCarro = new JMenuItem("Carro");
		mntmCarro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.setVisible(false);
				panel_1.setVisible(false);
				panel_2.setVisible(true);
			}
		});
		mnCadastrar.add(mntmCarro);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		panel = new JPanel();
		frame.getContentPane().add(panel, "name_554870927865835");
		panel.setLayout(null);
		
		JLabel lblBoaNoite = new JLabel("Boa noite!");
		lblBoaNoite.setBounds(68, 28, 101, 14);
		panel.add(lblBoaNoite);
		
		panel_1 = new JPanel();
		frame.getContentPane().add(panel_1, "name_554873846098748");
		panel_1.setLayout(null);
		
		JLabel lblCadastroDePessoas = new JLabel("Cadastro de Pessoas");
		lblCadastroDePessoas.setBounds(43, 34, 125, 14);
		panel_1.add(lblCadastroDePessoas);
		
		panel_2 = new JPanel();
		frame.getContentPane().add(panel_2, "name_554876365503483");
		panel_2.setLayout(null);
		
		JLabel lblCadastroDeCarros = new JLabel("Cadastro de Carros");
		lblCadastroDeCarros.setBounds(54, 29, 133, 14);
		panel_2.add(lblCadastroDeCarros);
	}
}
