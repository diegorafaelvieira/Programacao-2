package exemplos;

public class Carro {
	//Atributos
	public String marca;   
	public String modelo;
	public int ano;
	
	//M�todos
	public void andar() {   // void = n�o retorna nada
		System.out.println(this.marca + " " + this.modelo + " andando!");	
	}
	

}
