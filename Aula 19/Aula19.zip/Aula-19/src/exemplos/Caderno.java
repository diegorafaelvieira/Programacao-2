package exemplos;

public class Caderno extends Produto{

	//Atributos
		private int qtdFolhas;
		private String marca;

		//Construtor
		public Caderno(int codigo, int qtdFolhas, String marca) {
			super(codigo); 
			this.qtdFolhas = qtdFolhas;
			this.marca = marca;
			//System.out.println("Passou no construtor do Caderno");
		}
		public void imprimir() {
			super.imprimir();
			System.out.println("Quantidade de folhas: " + this.qtdFolhas);
			System.out.println("Marca: " + this.marca);
		}

		//GET e SET
		public int getQtdFolhas() {
			return qtdFolhas;
		}

		public void setQtdFolhas(int qtdFolhas) {
			this.qtdFolhas = qtdFolhas;
		}

		public String getMarca() {
			return marca;
		}

		public void setMarca(String marca) {
			this.marca = marca;
		}
}
