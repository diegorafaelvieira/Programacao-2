package exercicio4;

import java.util.Scanner;

public class TesteMatematica {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.print("Informe um valor para A: ");
		int A = entrada.nextInt();
		System.out.print("Informe um valor para B: ");
		int B = entrada.nextInt();
		
		System.out.print("Informe o tamanho do array com os valores a ser calculado a m�dia aritm�tica: ");
		int tam = entrada.nextInt();
		Double [] array = new Double[tam];
		double soma = 0;
		for (int i = 0; i < array.length; i++) {
			System.out.print("Informe um valor: ");
			double val = entrada.nextDouble();
			array[i]=val;
			soma = soma+array[i];
		}
		
		System.out.print("Informe o primeiro termo da PA: ");
		int a1 = entrada.nextInt();
		System.out.print("Informe o �ndice do n-�simo termo: ");
		int n = entrada.nextInt();
		System.out.print("Informe a raz�o da PA: ");
		int razao = entrada.nextInt();
		
		Matematica m1 = new Matematica(A,B,soma,tam,a1,n,razao);
		System.out.println();
		System.out.println("O resultado da subtra��o de A e B � "+Matematica.subtracao(A,B));
		System.out.println("A m�dia aritm�tica dos valores do array � "+Matematica.mediaAritmetica(soma,tam));
		System.out.println("O n-�simo termo da PA � "+Matematica.pa(a1, razao, n));
		
		
		entrada.close();
	}

	

}
