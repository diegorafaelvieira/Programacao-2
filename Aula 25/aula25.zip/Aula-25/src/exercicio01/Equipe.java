package exercicio01;

public class Equipe {
	private String nome;
	private String cidade;
	private Jogador goleiro;
	private Jogador fixo;
	private Jogador alaDireito;
	private Jogador alaEsquerdo;
	private Jogador pivo;
		

	
	//construtor
	public Equipe(String nome, String cidade, Jogador goleiro, Jogador fixo, Jogador alaDireito, Jogador alaEsquerdo,Jogador pivo) {
		this.nome = nome;
		this.cidade = cidade;
		this.goleiro = goleiro;
		this.fixo = fixo;
		this.alaDireito = alaDireito;
		this.alaEsquerdo = alaEsquerdo;
		this.pivo = pivo;
	}

	
	
	//GET e SET
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public Jogador getGoleiro() {
		return goleiro;
	}

	public void setGoleiro(Jogador goleiro) {
		this.goleiro = goleiro;
	}

	public Jogador getFixo() {
		return fixo;
	}

	public void setFixo(Jogador fixo) {
		this.fixo = fixo;
	}

	public Jogador getAlaDireito() {
		return alaDireito;
	}

	public void setAlaDireito(Jogador alaDireito) {
		this.alaDireito = alaDireito;
	}

	public Jogador getAlaEsquerdo() {
		return alaEsquerdo;
	}

	public void setAlaEsquerdo(Jogador alaEsquerdo) {
		this.alaEsquerdo = alaEsquerdo;
	}

	public Jogador getPivo() {
		return pivo;
	}

	public void setPivo(Jogador pivo) {
		this.pivo = pivo;
	}
	
	//Imprimir
	public void imprimiEquipe() {
		System.out.println(this.nome+"\nCidade: "+this.cidade+"\n>>>Jogadores<<<");
		System.out.println(this.goleiro.getNome()+" "+this.goleiro.getSobrenome()+" ("+this.goleiro.getPosicao()+")");
		System.out.println(this.fixo.getNome()+" "+this.fixo.getSobrenome()+" ("+this.fixo.getPosicao()+")");
		System.out.println(this.alaDireito.getNome()+" "+this.alaDireito.getSobrenome()+" ("+this.alaDireito.getPosicao()+")");
		System.out.println(this.alaEsquerdo.getNome()+" "+this.alaEsquerdo.getSobrenome()+" ("+this.alaEsquerdo.getPosicao()+")");
		System.out.println(this.pivo.getNome()+" "+this.pivo.getSobrenome()+" ("+this.pivo.getPosicao()+")");
		System.out.println();
	}


}