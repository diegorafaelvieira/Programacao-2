package exemplo2;

public class TesteString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// 3 maneiras de imprimir uma String
		/*String cidade0 = "Novo Hamburgo";
		System.out.println(cidade0);
		
		String cidade = new String ("Poa");
		System.out.println(cidade);
		
		char[] cidadeChar = {'F','e','l','i','z'};
		String cidade2 = new String(cidadeChar);
		System.out.println(cidade2); */
		
		String cidade1 = new String ("POA");
		
		
		if (cidade1.equalsIgnoreCase("Poa")) {
			System.out.println("Iguais");
		} else {
			System.out.println("Diferentes");
		}
		
		String cidade = new String ("Feliz");
		
		
		if (cidade.startsWith("Fe")) {
			System.out.println("Sim!Come�a");
		}
			
	    String cidade2 = new String ("Feliz");
			
			
	    if (cidade2.endsWith("iz")) {
			System.out.println("Sim!Termina");
		
	    }
	    
	    

	}
}	

 	    

