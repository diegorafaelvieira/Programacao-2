package exemplos2;

public class Livro {
	public String titulo;
	public String autor;
	
	public void imprimir() {
		System.out.println(this.titulo + " de " + this.autor);
	}
}
