// Neste exemplo, a classe ContaCorrente herda
// da classe Conta. Ou seja, Conta � a superclasse,
// enquanto ContaCorrente � a subclasse.

package exemplos;


public class ContaCorrente extends Conta {
	
		//Atributos
		public double limite;
		
		//Metodos
		public void cancelarLimite() {
		limite = 0;
		}

}
