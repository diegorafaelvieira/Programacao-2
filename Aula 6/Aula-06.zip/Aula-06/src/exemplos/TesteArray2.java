package exemplos;

import java.util.Random;
import java.util.Scanner;

public class TesteArray2 {

	public static void main(String[] args) {
		Random r = new Random();
		
		Scanner leitor = new Scanner(System.in);
		int [] [] notas = new int [3][2];
		
		for (int i = 0; i < notas.length; i++) {
			for (int j = 0; j < notas[i].length; j++) {
				notas[i][j] = 1 + r.nextInt(10);
			}
		}

		
		//System.out.println("Linhas "+notas.length);
		//System.out.println("Colunas "+notas[0].length);
		
		for (int i = 0; i < notas.length; i++) {   //percorre o da esquerda
			for (int j = 0; j < notas[i].length; j++) {  //percorre o da direita
				System.out.print(notas[i][j] + " ");
			}
			System.out.println();
		}
	}

}
