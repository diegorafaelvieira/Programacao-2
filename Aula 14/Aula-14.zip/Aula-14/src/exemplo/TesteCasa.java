package exemplo;

public class TesteCasa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*Casa c = new Casa ("Rua ABC 123",10,5f);
		System.out.print(c.getEndereco());
		System.out.print(c.getNumeroPecas());
		System.out.print(c.getMetragem()); */ 
		
		//Constru��o do ARRAY
		/*String[] dados = new String[3];
		dados[1] = "ABC";
		for (int i = 0; i < dados.length; i++) {
			System.out.println(dados[i]);
		}*/
		
		Casa[] condominio = new Casa[3];
		
		condominio[0] = new Casa("Rua XYZ 123",10,100.5f);
		condominio[1] = new Casa("Rua ABC 123",11,110.5f);
		condominio[2] = new Casa("Rua DEF 123",12,120.5f);
		
		for (int i = 0; i < condominio.length; i++) {
			System.out.println(condominio[i].getEndereco());
			System.out.println(condominio[i].getNumeroPecas());
			System.out.println(condominio[i].getMetragem());
			System.out.println();
		}
	}

}
