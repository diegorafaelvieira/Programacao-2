package gui;

import javax.swing.JFrame;

public class MeuApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Moldura
		JFrame f = new JFrame();
		//Painel
		MeuPainel p = new MeuPainel();
		//Junta Moldura e Painel
		f.add(p);
		f.setSize(600, 500);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);

	}

}
