package exercicio1;

import java.io.File;

public class CriaDiretorioEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File dir = new File("RegistroEx1");
		 
		dir.mkdir();
		
	}

}
