package exercicio1;

public class Bicicleta extends Veiculo {

	//Atributos
	private String cor;
	private int qtdMarchas;
	
	//GET e SET
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public int getQtdMarchas() {
		return qtdMarchas;
	}
	public void setQtdMarchas(int qtdMarchas) {
		this.qtdMarchas = qtdMarchas;
	}
	
	
	
}
