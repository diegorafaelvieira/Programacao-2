package exemplos;

public class Produto {

	//Atributos
		private int codigo;

		//GET e SET
		public int getCodigo() {
			return codigo;
		}

		public void setCodigo(int codigo) {
			this.codigo = codigo;
		}
		
		//Construtor
		public Produto(int codigo) {
			this.codigo = codigo;
			//System.out.println("Passou no construtor de Produto");
		}
		
		public void imprimir() {
			System.out.println("Codigo: " + this.codigo);
		}
}
