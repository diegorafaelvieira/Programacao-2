package exemplo;

abstract public class Animal {

	//Atributos
	private String nome;
	
	public Animal(String nome) {
	this.nome = nome;
	}
	
	//Metodo abstrato
	abstract public void emitirSom();
	
	//GET
	public String getNome() {
		return this.nome;
	}
}
