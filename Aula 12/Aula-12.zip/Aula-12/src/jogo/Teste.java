package jogo;

import jogo.equipamentos.Bola;
import jogo.equipamentos.Campo;
import jogo.pessoas.Jogador;
import jogo.pessoas.Juiz;
import jogo.pessoas.Treinador;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Treinador t1 = new Treinador();
		t1.setNome("Tite");
		
		Jogador g1 = new Jogador();
		g1.setNome("Taffarel");
		Jogador f1 = new Jogador();
		f1.setNome("Gamarra");
		Jogador ad1 = new Jogador();
		ad1.setNome("Jorginho");
		Jogador ae1 = new Jogador();
		ae1.setNome("Branco");
		Jogador p1 = new Jogador();
		p1.setNome("Ronaldo");
		
		Equipe e1 = new Equipe();
		e1.setTreinador(t1);
		e1.setGoleiro(g1);
		e1.setFixo(f1);
		e1.setAlaDireito(ad1);
		e1.setAlaEsquerdo(ae1);
		e1.setPivo(p1);
		
		
		Treinador t2 = new Treinador();
		t2.setNome("Abel Braga");
		
		Jogador g2 = new Jogador();
		g2.setNome("Clemer");
		Jogador f2 = new Jogador();
		f2.setNome("Indio");
		Jogador ad2 = new Jogador();
		ad2.setNome("Ceara");
		Jogador ae2 = new Jogador();
		ae2.setNome("Jorge Wagner");
		Jogador p2 = new Jogador();
		p2.setNome("Fernand�o");
		
		Equipe e2 = new Equipe();
		e2.setTreinador(t2);
		e2.setGoleiro(g2);
		e2.setFixo(f2);
		e2.setAlaDireito(ad2);
		e2.setAlaEsquerdo(ae2);
		e2.setPivo(p2);
		
		Juiz j = new Juiz();
		j.setNome("Simon");
		
		Bola bola = new Bola();
		bola.setMarca("Adidas");
		
		Campo campo = new Campo();
		campo.setLargura(20);
		campo.setComprimeto(40);
		
		Futebol f = new Futebol();
		f.setBola(bola);
		f.setCampo(campo);
		f.setJuiz(j);
		f.setEquipe1(e1);
		f.setEquipe2(e2);
		
		//Exemplos de acesso via GET
		f.getCampo().getLargura();
		f.getEquipe2().getPivo().getNome();
		
		// imprimir o nome do time 1
		System.out.println(e1.getGoleiro().getNome());
		System.out.println(e1.getFixo().getNome());
		System.out.println(e1.getAlaDireito().getNome());
		System.out.println(e1.getAlaEsquerdo().getNome());
		System.out.println(e1.getPivo().getNome());
		System.out.println(e1.getTreinador().getNome());
		
		// imprimir linha em branco
		System.out.println("");
		
		// imprimir o nome do time 2
		System.out.println(e2.getGoleiro().getNome());
		System.out.println(e2.getFixo().getNome());
		System.out.println(e2.getAlaDireito().getNome());
		System.out.println(e2.getAlaEsquerdo().getNome());
		System.out.println(e2.getPivo().getNome());
		System.out.println(e2.getTreinador().getNome());
				
		// imprimir linha em branco
		System.out.println("");
		
		// imprimir o nome do juiz
		System.out.println(j.getNome());
		
		// imprimir linha em branco
		System.out.println("");
		
		// imprimir medidas do campo
		System.out.println("O comprimento do campo �: " + (campo.getComprimeto())+ " metros");
		System.out.println("A largura do campo �: " + campo.getLargura()+ " metros");
		
		// imprimir linha em branco
		System.out.println("");
		
		//imprimir a bola
		System.out.println("A marca da bola � " + bola.getMarca());
		
		
	}

}
