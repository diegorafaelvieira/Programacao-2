
package exemplos;

public class Jaspion implements Jogador {

	@Override
	public void iniciar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mover(int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void apontar(int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atirar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sair() {
		// TODO Auto-generated method stub
		
	}

	
	
}
