package exercicio3;

public class Guitarrista extends Musico {

	//Atributos
	private String marcaGuitarra;

	//Metodos
	public String getMarcaGuitarra() {
		return marcaGuitarra;
	}

	public void setMarcaGuitarra(String marcaGuitarra) {
		this.marcaGuitarra = marcaGuitarra;
	}
	
	
	
	
}
