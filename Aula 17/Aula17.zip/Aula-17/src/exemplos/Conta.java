package exemplos;

public class Conta {

	
		private String correntista;
		private double saldo;
		
		
		public void retirar(double quantia) {
		saldo = saldo - quantia;
		}
		
		public void depositar(double quantia) {
		saldo = saldo + quantia;
		}
		
		public double obterSaldo() {
		return saldo;
		}

		//GET e SET
		public String getCorrentista() {
			return correntista;
		}

		public void setCorrentista(String correntista) {
			this.correntista = correntista;
		}

		public double getSaldo() {
			return saldo;
		}

		public void setSaldo(double saldo) {
			this.saldo = saldo;
		}
		
		
		

}
