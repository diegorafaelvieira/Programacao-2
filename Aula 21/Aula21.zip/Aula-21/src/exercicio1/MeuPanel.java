package exercicio1;

import java.awt.Graphics;

import javax.swing.JPanel;

public class MeuPanel extends JPanel {

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		/*
		g.drawLine(0,0,500,0);
		g.drawLine(0,50,500,50);
		g.drawLine(0,100,500,100);
		*/
		
		// Aqui faz o x
		for (int i = 0; i <= 10; i++) {
			g.drawLine(0,i*50,500,i*50);
			
			//Aqui faz o y
			for (int j = 0; j <=10; j++) {
				g.drawLine(50*j,0,j*50,500);
			}
		} 
		
	

		
		
	
		
	    
	    
	}	
	
}
