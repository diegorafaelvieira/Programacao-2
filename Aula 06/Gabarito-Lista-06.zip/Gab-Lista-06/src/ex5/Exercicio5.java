package ex5;

import java.util.Scanner;

public class Exercicio5 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		System.out.print("Numero 1: ");
		int n1 = reader.nextInt();
		System.out.print("Numero 2: ");
		int n2 = reader.nextInt();
		System.out.print("Numero 3: ");
		int n3 = reader.nextInt();
		
		if(n1 > n2) {
			if(n1 > n3) {
				// n1 EH O MAIOR DE TODOS
				// QUAL EH O MAIOR? n2 OU n3?
				if(n2 > n3) {
					System.out.print(n1 + "," + n2 + "," + n3);
				} else {
					System.out.print(n1 + "," + n3 + "," + n2);
				}
				
			// n3 EH O MAIOR DE TODOS
			} else {
				System.out.print(n3 + "," + n1 + "," + n2);
			}
		// n2 EH MAIOR QUE n1
		// FALTA VERIFICAR n3
		} else {
			// SE n3 EH MAIOR QUE n2 ENTAO n3 MAIOR QUE n1
			if(n3 > n2) {
				System.out.print(n3 + "," + n2 + "," + n1);
			} else {
				// n2 > n3
				// n2 > n1
				if(n3 > n1) {
					System.out.print(n2 + "," + n3 + "," + n1);
				} else {
					System.out.print(n2 + "," + n1 + "," + n3);
				}
			}
		}
		
		reader.close();
	}
	
}
