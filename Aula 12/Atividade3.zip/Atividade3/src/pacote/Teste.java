package pacote;

import java.util.Scanner;

public class Teste {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		
		System.out.print("Informe a popula��o da cidade A: ");
		double pA = entrada.nextDouble();
		System.out.print("Informe a taxa de crescimento anual de A: ");
		double tA = entrada.nextDouble();
		System.out.print("Informe a popula��o da cidade B: ");
		double pB = entrada.nextDouble();
		System.out.print("Informe a taxa de crescimento anual de B: ");
		double tB = entrada.nextDouble();
		
		CrescimentoPopulacional x = new CrescimentoPopulacional(pA, tA, pB, tB);
		x.Imprimi();
		
		entrada.close();
	}

}
