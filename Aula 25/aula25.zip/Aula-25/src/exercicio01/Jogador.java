package exercicio01;


public class Jogador {
	private String nomeJ;
	private String sobrenome;
	private String posicao;
	
	//construtor
	public Jogador(String nomeJ, String sobrenome, String posicao) {
		this.nomeJ = nomeJ;
		this.sobrenome = sobrenome;
		this.posicao = posicao;
	}
	
	
	
	//GET e SET
	public String getNome() {
		return nomeJ;
	}
	public void setNome(String nome) {
		this.nomeJ = nome;
	}
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public String getPosicao() {
		return posicao;
	}
	public void setPosicao(String posicao) {
		this.posicao = posicao;
	}
	
	
}
