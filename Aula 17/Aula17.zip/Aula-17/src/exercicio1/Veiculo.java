package exercicio1;

public class Veiculo {

	//Atributos
	private String marca;
	private String modelo;
	
	
	//GET e SET
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	
}
