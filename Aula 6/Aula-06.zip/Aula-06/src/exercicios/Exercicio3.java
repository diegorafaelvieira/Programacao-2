package exercicios;

import java.util.Random;

public class Exercicio3 {

	public static void main(String[] args) {
		/*
		 * Crie um programa que contenha um array de 1000 elementos chamado lista, sendo que cada
		elemento cont�m o valor do seu �ndice. Por exemplo, lista[0]=0, lista[1]=1, lista[2]=2, e
		assim sucessivamente at� lista[999]=999.
		Logo ap�s, utilize a classe Random para "embaralhar" (trocar de posi��o aleat�riamente) os itens
		do array. Finalmente, imprima os 1000 valores j� "embaralhados".
		 */
		
		Random r = new Random();
		int[] lista = new int[1000];
		
		for(int elemento : lista) {
			elemento = r.nextInt(1001);
			System.out.println(elemento);
			
		}
		
		
	}

}
