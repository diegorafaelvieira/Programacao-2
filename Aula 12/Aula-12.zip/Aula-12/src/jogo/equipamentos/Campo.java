package jogo.equipamentos;

public class Campo {
	private int largura;
	private int comprimeto;
	
	
	public int getLargura() {
		return largura;
	}
	public void setLargura(int largura) {
		this.largura = largura;
	}
	public int getComprimeto() {
		return comprimeto;
	}
	public void setComprimeto(int comprimeto) {
		this.comprimeto = comprimeto;
	}
	
}
