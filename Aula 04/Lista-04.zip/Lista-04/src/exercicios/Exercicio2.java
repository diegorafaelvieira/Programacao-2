package exercicios;



import javax.swing.JOptionPane;

public class Exercicio2 {

	public static void main(String[] args) {
		/*
		 * 2. Crie um programa que leia 10 Strings do usu�rio (use JOptionPane) e calcule o tamanho m�dio
		das Strings. O tamanho m�dio deve ser armazenado em um dado do tipo double (com parte
		fracion�ria). Finalmente, o programa deve mostrar o tamanho m�dio usando um JOptionPane
		 */

		double tamanho = 0;
		
		int i = 0;
		
		while(i<10) {
			i++;
			String x = JOptionPane.showInputDialog("Informe uma palavra: ");
			tamanho = tamanho + x.length();
		}
		
		double resultado = tamanho/10;
		
		JOptionPane.showInputDialog(null,"O tamanho m�dio das palavras � de "+ resultado + " caracteres");
		
	}
	
	

}
