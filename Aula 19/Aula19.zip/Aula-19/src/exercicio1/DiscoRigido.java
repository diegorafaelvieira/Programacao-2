package exercicio1;

public class DiscoRigido extends Componente {

	//Atributos
		private String capacidade;
		
		//Construtor
		public DiscoRigido(String fabricante, String modelo ,String capacidade) {
			super(fabricante,modelo);
			this.capacidade = capacidade;
		}
		
		public void imprimir() {
			super.imprimir();
			System.out.println("Capacidade: " + this.capacidade);	
		}

		//GET e SET
		public String getCapacidade() {
			return capacidade;
		}

		public void setCapacidade(String capacidade) {
			this.capacidade = capacidade;
		}
}
