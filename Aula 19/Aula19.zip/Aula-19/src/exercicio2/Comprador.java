package exercicio2;

public class Comprador  {

	//Atributos
	private Produto p;
	

	public void consulta(Produto p) {
		p.Imprimir();
	}
	

	//GET e SET
	public Produto getP() {
		return p;
	}

	public void setP(Produto p) {
		this.p = p;
	}
}
