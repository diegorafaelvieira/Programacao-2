package ex4;


import java.util.Scanner;

public class Exercicio4 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		System.out.print("Numero: ");
		int numeroInformado = reader.nextInt();
		
		boolean triangular = false;
		int base = 1;
		int numeroCalculado = 1*2*3; 
		
		while(numeroCalculado <= numeroInformado) {
			
			if(numeroCalculado == numeroInformado) {
				triangular = true;
			}
			
			numeroCalculado = base * (base+1) * (base+2);
			base++;
		}
		
		if(triangular) {
			System.out.println(numeroInformado + " eh triangular!");
		} else {
			System.out.println(numeroInformado + " NAO eh triangular!");
		}
		
		reader.close();
	}
	
}

