package exercicio1;

import javax.swing.JFrame;

import gui.MeuPainel;

public class TesteApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Moldura
		JFrame f = new JFrame();
		//Painel
		MeuPanel p = new MeuPanel();
		
		//Junta Moldura e Painel
		f.add(p);
		f.setSize(500, 500);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);

		
		
	}

}
