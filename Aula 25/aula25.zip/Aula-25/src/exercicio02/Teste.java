package exercicio02;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Teste {

	public static void main(String[] args) {
		//Cria��o ArrayList estacionamento
		ArrayList<Estacionamento> estacionamento = new ArrayList<Estacionamento>();
		
		//Declara��o de vari�veis e Scanner
		Scanner leitor = new Scanner(System.in);
		String entrada = "N�o Entrou!", saida = "N�o Saiu!", modelo = "", marca = "", cor = "", placa = "";
		int op = 1;
		
		//Cria��o de um objeto que pega a Hora atual do sistema
		SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm");
	 
		//Condi��o de continuar e finalizar o sistema
		while(op == 1 || op == 2) {
			System.out.print("Opera��es!\n(1)Entrar no Estacionamento;\n(2)Sair do Estacionamento;\n(3)Nenhuma;\nEscolha uma opera��o: ");
			op = leitor.nextInt();
		
			//Switch que seleciona a opera��o informada
			switch (op) {
				case 1:
					saida = "N�o Saiu!";
					//Pega a hora e manda para a var entrada
					entrada = dateFormat.format( new Date() );
					System.out.println();
					System.out.print("Modelo do carro: ");
					modelo = leitor.next();
					System.out.print("Marca do carro: ");
					marca = leitor.next();
					System.out.print("Cor do carro: ");
					cor = leitor.next();
					System.out.print("Placa do carro: ");
					placa = leitor.next();
					System.out.println();
					Carro c = new Carro(modelo, marca, cor, placa);
					Estacionamento e = new Estacionamento(entrada, saida,c);
					estacionamento.add(e);
					break;
		
				case 2:
					if(estacionamento.size() == 0){
						System.out.println();
						System.out.println("N�o h� carros no estacionamento!");
						System.out.println();
					}
					else {
						//Pega a hora e manda para a var saida
						saida = dateFormat.format( new Date() );
						System.out.println();
						System.out.print("Informe sua placa: ");
						placa = leitor.next();
						System.out.println();
						for (int i = 0; i < estacionamento.size(); i++) {
							if(estacionamento.get(i).getCarro().getPlaca().equalsIgnoreCase(placa)){
								System.out.println("Modelo / Marca / Cor / Placa");
								System.out.println();
								estacionamento.get(i).setSaida(saida);
								estacionamento.get(i).imprimiEstacionamento();
								estacionamento.remove(i);
								System.out.println();
								System.out.println("Tenha Um Bom Dia!");
								System.out.println();
							}
						}
					}
					break;
				case 3:
					System.out.println();
					System.out.println("Saindo...");
					System.out.println();
					if(estacionamento.size()>0) {
						System.out.println("Modelo / Marca / Cor / Placa");
						System.out.println();
						for (int i = 0; i < estacionamento.size(); i++) {
							estacionamento.get(i).imprimiEstacionamento();
						}
					}
					break;
				}
			}
		leitor.close();
	}		
}		
		
		
	
		
	










 