package exercicio1;

import java.util.Scanner;



public class TesteCarro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner leitor = new Scanner(System.in);
		
		Carro[] frota = new Carro[3];
		
		//Leitura da Impress�o
		for (int i = 0; i < frota.length; i++) {
			System.out.print("Informa a marca " + (i+1) + ":");
			String marca = leitor.nextLine();
			System.out.print("Informa o modelo " + (i+1) + ":");
			String modelo = leitor.nextLine();
			System.out.print("Informa a placa " + (i+1) + ":");
			String placa = leitor.nextLine();
			frota[i] = new Carro (modelo,marca,placa);
			System.out.println();
		}
		
		//C�digo da Impress�o
		for (int i = 0; i < frota.length; i++) {
			System.out.print("O carro " + (i+1) + " � um " + 
		    frota[i].getModelo() + " " +
			frota[i].getMarca() + " com placa " +
		    frota[i].getPlaca() );
		}
		
		
		leitor.close();
		
		
		}
		

	

}
