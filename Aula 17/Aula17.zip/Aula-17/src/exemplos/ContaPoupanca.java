// Neste exemplo, a classe ContaPoupanca tamb�m herda
// da classe Conta. Note que o m�todo atualiza saldo
// usa o atributo saldo que foi herdado de Conta.


package exemplos;

public class ContaPoupanca extends Conta {
	
	//Atributos
	public double taxaJuros;

	//Metodos
	public void atualizaSaldo() {
		double novoSaldo = this.obterSaldo();
		novoSaldo = novoSaldo * taxaJuros;
 		this.depositar(novoSaldo);
	}


}
