package exercicio3replace;

import java.util.Scanner;

public class Exercicio3UsandoReplace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner leitor = new Scanner(System.in);
		System.out.print("Digite uma frase:");
		String frase = leitor.nextLine();
		
		
		frase = frase.replace("a", "*");
		System.out.println(frase);		
		
		leitor.close();
		
	}	
}
