package exemplos;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class Cenario extends JPanel{

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		File arquivo = new File("res/fundo.png");
		File arquivo2 = new File("res/pacman.png");
		File arquivo3 = new File("res/fantasma.png");
		try {
			BufferedImage imagem = ImageIO.read(arquivo);
			BufferedImage imagem2 = ImageIO.read(arquivo2);
			BufferedImage imagem3 = ImageIO.read(arquivo3);
			
			g.drawImage(imagem, 0, 0, 350, 400, null);
			g.drawImage(imagem2, 35, 68, 20, 20, null);
			g.drawImage(imagem3, 165,165, 20, 20, null);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
}
