package exemplo;

import java.util.ArrayList;

public class TesteArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> itens = new ArrayList<String>();
		itens.add("Feliz");
		itens.add(1,"Porto Alegre");
		itens.add(0,"Ivoti");

		//Remove tudo
		//itens.clear();

		//Adiciona Ivoti novamente
		//itens.add(0,"Ivoti");
		
		//Remove o primeiro valor da lista
		//itens.remove(0);
		
		//Verifica se a palavra se encontra no indice
		int indice = itens.indexOf("Ivoti");
		System.out.println("------ Tem Ivoti no indice  " + indice);
		
		//Para saber se existe na lista
		if(itens.contains("Ivoti")) {
			System.out.println("----> Tem Ivoti!");
		} 
		
		for (int i = 0; i < itens.size(); i++) {
			System.out.println(itens.get(i));
		}
		
	}

}
