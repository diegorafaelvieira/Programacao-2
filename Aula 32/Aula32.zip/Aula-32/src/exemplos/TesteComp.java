package exemplos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class TesteComp {

	private JFrame frame;
	private JCheckBox chckbxAceito;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JRadioButton rdbtnFumante;
	private JRadioButton rdbtnNoFumante;
	private JPasswordField passwordField;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TesteComp window = new TesteComp();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TesteComp() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		chckbxAceito = new JCheckBox("Aceito");
		chckbxAceito.setBounds(19, 23, 97, 23);
		frame.getContentPane().add(chckbxAceito);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxAceito.isSelected()) {
					System.out.println("Checkbox selecionado");
				} else {
					System.out.println("Checkox N�O seleciolado");
				}
				
				System.out.println(rdbtnFumante.isSelected());
				System.out.println(rdbtnNoFumante.isSelected());
				
				System.out.println(passwordField.getPassword());
				
				System.out.println(comboBox.getSelectedItem());
			}
		});
		btnOk.setBounds(167, 227, 89, 23);
		frame.getContentPane().add(btnOk);
		
		rdbtnFumante = new JRadioButton("Fumante");
		buttonGroup.add(rdbtnFumante);
		rdbtnFumante.setBounds(19, 49, 109, 23);
		frame.getContentPane().add(rdbtnFumante);
		
		rdbtnNoFumante = new JRadioButton("N\u00E3o Fumante");
		buttonGroup.add(rdbtnNoFumante);
		rdbtnNoFumante.setBounds(19, 75, 109, 23);
		frame.getContentPane().add(rdbtnNoFumante);
		
		passwordField = new JPasswordField();
		passwordField.setEchoChar('X');
		passwordField.setBounds(29, 105, 178, 20);
		frame.getContentPane().add(passwordField);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Argentina", "Brasil", "Chile"}));
		comboBox.setBounds(19, 136, 122, 20);
		frame.getContentPane().add(comboBox);
	}
}
