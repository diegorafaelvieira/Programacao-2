package exemplos;

public interface Jogador {

	public static final int x = 200;
	
	
	
	//Metodos abstratos (contem somente abstratos)
	public abstract void iniciar();
	public abstract void mover(int x, int y);
	public abstract void apontar(int x, int y);
	public abstract void atirar();
	public abstract void sair();
	
	
}
