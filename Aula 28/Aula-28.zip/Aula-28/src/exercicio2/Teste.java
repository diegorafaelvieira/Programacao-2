package exercicio2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner leitor = new Scanner(System.in);
		
		ArrayList<Pessoa> p1 = new ArrayList<Pessoa>();
		
		int w = 1;
		
		while(w == 1) {
			System.out.println("Informe 1 para cadastrar ou 0(zero) para sair: ");
			int opcao = leitor.nextInt();
			
			switch (opcao) {
			case 1:
				System.out.println("Informe o nome da pessoa: ");
				String nome = leitor.next();
				System.out.println("Informe o sobrenome da pessoa: ");
				String sobrenome = leitor.next();
				p1.add(new Pessoa(nome,sobrenome));
				break;

			default:
				w = 0;
				System.out.println("Tchau!Confira o arquivo pessoas.txt");
				//Criar arquivo
				
				File documento = new File("RegistroEx2/pessoas.txt");
				
				try {
					documento.createNewFile();
					FileWriter f1 = new FileWriter(documento,false);
					BufferedWriter b1 = new BufferedWriter(f1);
					
					for (int i = 0; i < p1.size(); i++) {
						b1.write("___PESSOA" + i +"___" + "\n");
						b1.write(p1.get(i).getNome()+ "\n");
						b1.write(p1.get(i).getSobrenome()+ "\n");
						System.out.println("");
						
						
						b1.close();
						f1.close();
					}
				} catch (IOException e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				break;
			}
			
			
		}
		
		
	}

}
