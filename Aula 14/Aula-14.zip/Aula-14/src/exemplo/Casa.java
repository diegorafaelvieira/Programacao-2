package exemplo;

public class Casa {
	
	
	private String endereco;
	private int numeroPecas;
	private float metragem;
	
	//GET e SET
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public int getNumeroPecas() {
		return numeroPecas;
	}
	public void setNumeroPecas(int numeroPecas) {
		this.numeroPecas = numeroPecas;
	}
	public float getMetragem() {
		return metragem;
	}
	public void setMetragem(float metragem) {
		this.metragem = metragem;
	}
	
	//Metodo
    public Casa(String endereco, int numeroPecas, float metragem) {	
		this.endereco = endereco;
		this.numeroPecas = numeroPecas;
		this.metragem = metragem;
	}
	
	
	
}
