package exercicio1;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		Circulo c1 = new Circulo("Circulo" , 15);
		System.out.println("Area Circulo:" + c1.calculaArea());
		System.out.println("Perimetro Circulo:" + c1.calculaPerimetro());
		
		System.out.println();
		
		Retangulo r1 = new Retangulo("Retangulo", 5 , 2);
		System.out.println("Area Retangulo:" + r1.calculaArea());
		System.out.println("Perimetro Retangulo:"+r1.calculaPerimetro());
	}

}
