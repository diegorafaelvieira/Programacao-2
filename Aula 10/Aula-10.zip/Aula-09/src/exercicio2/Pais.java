package exercicio2;

public class Pais {
	public String nome;
	public String capital;
	public int habitantes;
	
	public void informacoes() {
		System.out.println("O pa�s " + this.nome + " com a capital " + this.capital + " possui " + this.habitantes + " habitantes");
	}

}
