package exercicio2;

import javax.swing.JFrame;

import javax.swing.JOptionPane;


public class TesteApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		//Moldura
		JFrame f = new JFrame();
		//Painel
		MeuPainel p = new MeuPainel();
					
		//Junta Moldura e Painel
		f.add(p);
		f.setSize(500, 500);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);	
		
		
		// Retangulo
		MeuPainel rect = new MeuPainel();
		String valorR1 = JOptionPane.showInputDialog("Digite o tamanho do ret�ngulo: ");	
		int rect1 = Integer.parseInt(valorR1);
		String valorR2 = JOptionPane.showInputDialog("Digite o tamanho do ret�ngulo: ");	
		int rect2 = Integer.parseInt(valorR2);
		String valorR3 = JOptionPane.showInputDialog("Digite o tamanho do ret�ngulo: ");	
		int rect3 = Integer.parseInt(valorR3);
		String valorR4 = JOptionPane.showInputDialog("Digite o tamanho do ret�ngulo: ");	
		int rect4 = Integer.parseInt(valorR4);
	
		//Elipse
		MeuPainel oval = new MeuPainel();	
		String valorO1 = JOptionPane.showInputDialog("Digite o tamanho da elipse: ");	
		int oval1 = Integer.parseInt(valorO1);
		String valorO2 = JOptionPane.showInputDialog("Digite o tamanho da elipse: ");	
		int oval2 = Integer.parseInt(valorO2);
		String valorO3 = JOptionPane.showInputDialog("Digite o tamanho da elipse: ");	
		int oval3 = Integer.parseInt(valorO3);
		String valorO4 = JOptionPane.showInputDialog("Digite o tamanho da elipse: ");	
		int oval4 = Integer.parseInt(valorO4);
	

		
	}

}
