package exercicio1;

public abstract class FiguraGeometrica {

	//Atributos
	protected String nome;
	
	//Metodos
	public FiguraGeometrica(String nome) {
	this.nome = nome;
	 }
	
	//GET
	public String getNome() {
	return this.nome;
	 }
	
	abstract public double calculaPerimetro();
	abstract public double calculaArea();
}
