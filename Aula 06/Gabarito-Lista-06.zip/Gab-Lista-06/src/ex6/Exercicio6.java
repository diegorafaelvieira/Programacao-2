package ex6;

import java.util.Scanner;

public class Exercicio6 {

	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		
		int n1 = 0;
		int n2 = 0;
		
		do {
			System.out.print("Numero n1: ");
			n1 = reader.nextInt();
			System.out.print("Numero n2: ");
			n2 = reader.nextInt();
		
			if(n1 <= n2) {
				for(int i=n1; i<=n2; i++) {
					if(i%3 == 0) {
						System.out.println("Numero " + i + " eh divisivel por 3!");
					}
				}
			} else {
				System.out.println("O numero n1 nao pode ser maior que n2!");
				System.out.println("Informe novamente ambos numeros.");
				System.out.println();
			}
		} while(n1 > n2);
		
		reader.close();
	}
}
