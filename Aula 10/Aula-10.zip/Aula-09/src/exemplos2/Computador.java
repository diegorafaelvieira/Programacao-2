package exemplos2;

public class Computador {
	public String modelo;
	public int ano;
	public String fabricante;

}
