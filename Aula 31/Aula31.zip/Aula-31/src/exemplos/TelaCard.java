package exemplos;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.CardLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaCard extends JFrame {

	private JPanel contentPane;
	private JTextField txtNome;
	private JPanel panelBV;
	private JLabel lblOla;
	private JButton btnAvancar;
	private JPanel panelCadastro;
	private JLabel lblIdade;
	private JTextField txtIdade;
	private JLabel lblEndereco;
	private JTextField txtEndereco;
	private JLabel lblFone;
	private JTextField txtFone;
	private JButton btnOk;
	private JPanel panelSaida;
	private JLabel lblIdade_1;
	private JLabel lblMostraIdade;
	private JLabel lblEndereo;
	private JLabel lblMostraEndereco;
	private JLabel lblFone_1;
	private JLabel lblMostraFone;
	private JButton btnSair;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaCard frame = new TelaCard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaCard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		JPanel panelEntrada = new JPanel();
		contentPane.add(panelEntrada, "name_298906736453657");
		panelEntrada.setLayout(null);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(30, 24, 46, 14);
		panelEntrada.add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setBounds(100, 21, 261, 20);
		panelEntrada.add(txtNome);
		txtNome.setColumns(10);
		
		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String nome = txtNome.getText();
			lblOla.setText("Ol�!  " + nome + " !");
			panelEntrada.setVisible(false);	
			panelBV.setVisible(true);	
			}
		});
		btnEntrar.setBounds(166, 196, 89, 23);
		panelEntrada.add(btnEntrar);
		
		panelBV = new JPanel();
		contentPane.add(panelBV, "name_298924061859691");
		panelBV.setLayout(null);
		
		lblOla = new JLabel("Ol\u00E1!");
		lblOla.setBounds(37, 32, 222, 14);
		panelBV.add(lblOla);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelBV.setVisible(false);
				panelEntrada.setVisible(true);
			}
		});
		btnVoltar.setBounds(170, 217, 89, 23);
		panelBV.add(btnVoltar);
		
		btnAvancar = new JButton("Avan\u00E7ar");
		btnAvancar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelBV.setVisible(false);
				panelCadastro.setVisible(true);
			}
		});
		btnAvancar.setBounds(170, 166, 89, 23);
		panelBV.add(btnAvancar);
		
		panelCadastro = new JPanel();
		contentPane.add(panelCadastro, "name_299513043750535");
		panelCadastro.setLayout(null);
		
		lblIdade = new JLabel("Idade:");
		lblIdade.setBounds(33, 26, 46, 14);
		panelCadastro.add(lblIdade);
		
		txtIdade = new JTextField();
		txtIdade.setBounds(70, 23, 86, 20);
		panelCadastro.add(txtIdade);
		txtIdade.setColumns(10);
		
		lblEndereco = new JLabel("Endere\u00E7o:");
		lblEndereco.setBounds(33, 83, 65, 14);
		panelCadastro.add(lblEndereco);
		
		txtEndereco = new JTextField();
		txtEndereco.setBounds(108, 80, 213, 20);
		panelCadastro.add(txtEndereco);
		txtEndereco.setColumns(10);
		
		lblFone = new JLabel("Fone:");
		lblFone.setBounds(33, 139, 46, 14);
		panelCadastro.add(lblFone);
		
		txtFone = new JTextField();
		txtFone.setBounds(70, 136, 139, 20);
		panelCadastro.add(txtFone);
		txtFone.setColumns(10);
		
		btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String idade = txtIdade.getText();
			String endereco = txtEndereco.getText();
			String fone = txtFone.getText();
			lblMostraIdade.setText(idade);
			lblMostraEndereco.setText(endereco);
			lblMostraFone.setText(fone);
			panelCadastro.setVisible(false);
			panelSaida.setVisible(true);
			}
		});
		btnOk.setBounds(153, 201, 89, 23);
		panelCadastro.add(btnOk);
		
		panelSaida = new JPanel();
		contentPane.add(panelSaida, "name_299811320568563");
		panelSaida.setLayout(null);
		
		lblIdade_1 = new JLabel("Idade:");
		lblIdade_1.setBounds(39, 25, 46, 14);
		panelSaida.add(lblIdade_1);
		
		lblMostraIdade = new JLabel("");
		lblMostraIdade.setBounds(76, 25, 79, 14);
		panelSaida.add(lblMostraIdade);
		
		lblEndereo = new JLabel("Endere\u00E7o:");
		lblEndereo.setBounds(39, 74, 63, 14);
		panelSaida.add(lblEndereo);
		
		lblMostraEndereco = new JLabel("");
		lblMostraEndereco.setBounds(126, 74, 46, 14);
		panelSaida.add(lblMostraEndereco);
		
		lblFone_1 = new JLabel("Fone:");
		lblFone_1.setBounds(39, 127, 46, 14);
		panelSaida.add(lblFone_1);
		
		lblMostraFone = new JLabel("");
		lblMostraFone.setBounds(95, 127, 46, 14);
		panelSaida.add(lblMostraFone);
		
		btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelSaida.setVisible(false);
			}
		});
		btnSair.setBounds(164, 198, 89, 23);
		panelSaida.add(btnSair);
	}
}
