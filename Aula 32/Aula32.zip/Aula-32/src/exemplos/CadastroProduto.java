package exemplos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class CadastroProduto {

	private JFrame frame;
	private JTextField textField;
	private ArrayList<Produto> produtos = new ArrayList<Produto>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroProduto window = new CadastroProduto();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CadastroProduto() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblCdigo = new JLabel("C\u00F3digo:");
		lblCdigo.setBounds(34, 30, 46, 14);
		frame.getContentPane().add(lblCdigo);
		
		textField = new JTextField();
		textField.setBounds(77, 27, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnCriarProduto = new JButton("Criar Produto");
		btnCriarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//criar objeto   // colocar try catch
				String codigo = textField.getText();
				int codigoNumerico = Integer.parseInt(codigo);
				Produto p =new Produto(codigoNumerico);
				//System.out.println("Codigo = " + p.getCodigo());
				produtos.add(p);
				
			}
		});
		btnCriarProduto.setBounds(77, 97, 133, 23);
		frame.getContentPane().add(btnCriarProduto);
	}
}
