package teste;

public class Exemplo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Pessoa p1 = new Pessoa("Maria",23);
		System.out.println(p1.getNome());
		System.out.println(p1.getIdade());
	}

}
