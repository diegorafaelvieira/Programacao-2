package exemplos;

public class TesteContas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ContaCorrente cc = new ContaCorrente();
		cc.setCorrentista  ("Fulano");
		cc.setSaldo (1000);
		cc.limite = 500;
		cc.retirar(200);
		System.out.println(cc.getSaldo());
		
		
		ContaPoupanca cp = new ContaPoupanca();
		cp.setCorrentista ("Z�");
		cp.setSaldo (3000);
		cp.taxaJuros = 1.006;
		cp.atualizaSaldo();
		System.out.println(cp.getSaldo());
		
		
	}

}
