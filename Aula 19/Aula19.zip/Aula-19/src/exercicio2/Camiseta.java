package exercicio2;

public class Camiseta extends Produto{

	private String cor;
	
	//Construtor
	public Camiseta(String nome, double valor, String cor) {
		super(nome,valor);
		this.cor = cor;
	}
	
	public void imprimir() {
		super.Imprimir();
		System.out.println("Cor: " + this.cor);	
	}

	//GET e SET
	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}
	
	
	
}
