package exercicio1;

public class Apartamento {

	//Atributos
	private int numero;
	private int comodos;
	
	//GET e SET
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public int getComodos() {
		return comodos;
	}
	public void setComodos(int comodos) {
		this.comodos = comodos;
	}
	
	//Construtor
	public Apartamento(int numero, int comodos) {
		
		this.numero = numero;
		this.comodos = comodos;
	}
	
	
	
	
}
