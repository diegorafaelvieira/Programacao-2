package exemplos;

public class Matematica {

	public static int soma(int a , int b) {
		return a + b;
	}
	
}
