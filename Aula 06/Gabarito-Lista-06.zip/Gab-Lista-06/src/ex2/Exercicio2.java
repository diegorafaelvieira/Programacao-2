package ex2;

import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {

		Scanner leitor = new Scanner(System.in);		
		
		System.out.print("Digite o numero de alunos: ");
		int numeroAlunos = leitor.nextInt();
		
		System.out.print("Digite o numero de avaliacoes: ");
		int numeroAvaliacoes = leitor.nextInt();

		double[][] notas = new double[numeroAlunos][numeroAvaliacoes]; 
		String[] nomes = new String[numeroAlunos];
				
		for (int i = 0; i < numeroAlunos; i++) {
			System.out.print("Digite o nome do aluno " + (i+1) + ": ");
			nomes[i] = leitor.next();
		
			for (int j = 0; j < numeroAvaliacoes; j++) {
				System.out.print("Digite a nota " + (j+1) + " do aluno " + nomes[i] + ": ");
				notas[i][j] = leitor.nextDouble();
			}
		}
		
		System.out.println("-------------");
		
		for (int i = 0; i < numeroAlunos; i++) {
			double soma = 0;
			for (int j = 0; j < numeroAvaliacoes; j++) {
				soma = soma + notas[i][j];
			}
			double media = soma / numeroAvaliacoes;
			System.out.println("O aluno " + nomes[i] + " teve media " + media);
		}
		
		System.out.println("-------------");

		for (int j = 0; j < numeroAvaliacoes; j++) {
			double soma = 0;
			for (int i = 0; i < numeroAlunos; i++) {
				soma = soma + notas[i][j];
			}
			double media = soma / numeroAlunos;
			System.out.println("A media na avaliacao " + (j+1) + " foi " + media);
		}
		
		leitor.close();
	}

}
