package exercicio2;

public class Produto {

		//Atributos
		private String nome;
		private double valor;
		
		//Construtor
		public Produto(String nome, double valor){
			this.nome = nome;
			this.valor = valor;
		}
		
		
		public void Imprimir() {
			System.out.println("Nome do produto: " + this.nome);
			System.out.println("Valor do produto: " + this.valor);
		}


		//GET e SET
		public String getNome() {
			return nome;
		}


		public void setNome(String nome) {
			this.nome = nome;
		}


		public double getValor() {
			return valor;
		}


		public void setValor(double valor) {
			this.valor = valor;
		}

		
		
		
		
		
}
