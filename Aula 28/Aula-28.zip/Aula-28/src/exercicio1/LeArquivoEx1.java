package exercicio1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class LeArquivoEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File arquivo= new File("RegistroEx1/numeros1.txt");

		int soma = 0;
		//Aqui não vai true ou false
		try {
			FileReader leitor = new FileReader(arquivo);
			BufferedReader buffer = new BufferedReader(leitor);

			String linha = null;


			while((linha = buffer.readLine()) !=null) {
				System.out.println(linha);

				int s = Integer.parseInt(linha);
				soma += s;
			
			}



			//Não esquecer de fechar
			buffer.close();
			leitor.close();

			//Trocar para IOException
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		File arquivo2 = new File("RegistroEx1/soma.txt"); 		


		try {
			
			FileWriter leitor2 = new FileWriter(arquivo2,false);
			BufferedWriter buffer2 = new BufferedWriter(leitor2);
			
			buffer2.write("A soma dos valores é: " + soma + "\n");
			
			buffer2.close();
			leitor2.close();

		} catch (IOException e2) {
			// TODO: handle exception
			e2.printStackTrace();
		}
	}

}
