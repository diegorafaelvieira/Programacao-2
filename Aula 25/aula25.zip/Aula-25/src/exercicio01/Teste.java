package exercicio01;


import java.util.ArrayList;
import java.util.Scanner;



public class Teste {

	public static void main(String[] args) {
		//ArrayList das equipes
		ArrayList<Equipe> equipes = new ArrayList<Equipe>();

		//Declara��o de vari�veis e Scanner
		String nomeEq = "", cidadeEq = "", nome, sobrenome;
		int x, op = 1,posicao;
		Jogador  g1 = null, f1 = null, ad1 = null, ae1 = null, p1 = null;
		Scanner entrada = new Scanner(System.in);
		
		//verifica��o de erros com try e catch e inicio do programa
		try {
		while(op == 1 || op == 2) {
			System.out.print("Escolha uma opera��o!\n(1)Inserir Equipe;\n(2)Excluir Equipe;\n(3)Sair;\nInforme uma opera��o: ");
			op = entrada.nextInt();
			System.out.println();
			if(op==1) {
				System.out.print("Nome da Equipe: ");
				nomeEq = entrada.next();
				System.out.print("Cidade da Equipe: ");
				cidadeEq = entrada.next();
				System.out.println("Equipe Criada!");
				System.out.println("Informe os jogadores!");
			}
		
		//switch para definir a opera��o  de inserir, excluir ou sair
		switch (op) {
			case 1:
				//Inserir jogadores
				x = 0;
				while(x<5){
					System.out.println();
					System.out.print("Nome do jogador: ");
					nome = entrada.next();
					System.out.print("Sobrenome do jogador: ");
					sobrenome = entrada.next();
					System.out.print("Escolha uma Posi��o!\n(1)Goleiro;\n(2)Fixo;\n(3)Ala Direito;\n(4)Ala Esquerdo;\n(5)Pivo;\nPosi��o do Jogador: ");
					posicao = entrada.nextInt();
					System.out.println();
			
			
					//condi��o de posi��o e cria��o do objeto jogador
					if (posicao == 1) {
						Jogador g = new Jogador(nome, sobrenome, "Goleiro");
						g1 = g;
						x++;
					}
					else if(posicao == 2) {
						Jogador f = new Jogador(nome, sobrenome, "Fixo");
						f1 = f;
						x++;
					}
					else if(posicao == 3) {
						Jogador ad = new Jogador(nome, sobrenome, "Ala Direito");
						ad1 = ad;
						x++;
					}
					else if(posicao == 4) {
						Jogador ae = new Jogador(nome, sobrenome, "Ala Esquerdo");
						ae1 = ae;
						x++;
					}
					else if(posicao == 5) {
						Jogador p = new Jogador(nome, sobrenome, "Pivo");
						p1 = p;
						x++;
					}

				}
			
				Equipe e = new Equipe(nomeEq, cidadeEq, g1, f1, ad1, ae1, p1);
				equipes.add(e);
				break;
			case 2:
				if(equipes.size() == 0){
					System.out.println("Nenhuma Equipe Inserida no Sistema!");
					System.out.println();
				}
				else {
					System.out.print("Informe o nome da equipe a excluir: ");
					nomeEq = entrada.next();
					for (int i = 0; i < equipes.size(); i++) {
						if(equipes.get(i).getNome().equalsIgnoreCase(nomeEq)) {
							equipes.remove(i);
							System.out.println("Equipe removida com sucesso!");
						}
						else {
							System.out.println("Equipe n�o encontrada!");
						}
					}
				}
				break;
			case 3:
				System.out.println();
				System.out.println("Saindo...");
				System.out.println();
				for (int i = 0; i < equipes.size(); i++) {
					equipes.get(i).imprimiEquipe();
				}
				break;
		}	
			
		}
		} catch (Exception e) {
			System.out.println(">>> Opera��o ou Dados Inv�lidos<<< Erro: "+e);
		}
			entrada.close();
	}
}




















