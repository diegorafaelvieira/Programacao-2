package exercicio1a;

public class Casa {
	public String cor ;
	public int numero;
	public int qtdMoradores;
	
	public void imprimir() {
		System.out.println("A casa de cor " + this.cor + " de n�mero " + this.numero + " possui " + this.qtdMoradores + " moradores");
	}
	
	
}
