package ex2;

import java.util.Random;

public class Exercicio2 {
	
	public static void main(String[] args) {
		
		Random r = new Random();
		Carta[][] c = new Carta[4][13];
		
		// Cria o baralho
		for (int naipe = 0; naipe < c.length; naipe++) {
			for (int numero = 0; numero < c[naipe].length; numero++) {
				c[naipe][numero] = new Carta(naipe,numero);
			}
		}
			
		// Imprime o baralho antes
		System.out.println("Antes:");
		for (int naipe = 0; naipe < c.length; naipe++) {
			for (int numero = 0; numero < c[naipe].length; numero++) {
				System.out.println(c[naipe][numero].getNaipe() + " : " 
							+ c[naipe][numero].getNumero());
			}
		}
		
		
		// Embaralha
		for (int emb = 0; emb < 10000; emb++) {
			int naipe1 = r.nextInt(4);
			int naipe2 = r.nextInt(4);
			int numero1 = r.nextInt(13);
			int numero2 = r.nextInt(13);
			
			Carta temp = c[naipe1][numero1];
			c[naipe1][numero1] = c[naipe2][numero2];
			c[naipe2][numero2] = temp;
		}
		
		// Imprime o baralho depois de embaralhar
		System.out.println();
		System.out.println("Depois:");
		for (int naipe = 0; naipe < c.length; naipe++) {
			for (int numero = 0; numero < c[naipe].length; numero++) {
				System.out.println(c[naipe][numero].getNaipe() + " : " + c[naipe][numero].getNumero());
			}
		}
	}
	
}
