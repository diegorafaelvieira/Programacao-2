package exercicio4;

public class Matematica {
	private int a;
	private int b;
	private double soma;
	private int tamanho;
	private int a1;
	private int n;
	private int razao;
	
	
	
	//GET e SET
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	public double getSoma() {
		return soma;
	}
	public void setSoma(double soma) {
		this.soma = soma;
	}
	public int getTamanho() {
		return tamanho;
	}
	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}
	public int getA1() {
		return a1;
	}
	public void setA1(int a1) {
		this.a1 = a1;
	}
	public int getN() {
		return n;
	}
	public void setN(int n) {
		this.n = n;
	}
	public int getRazao() {
		return razao;
	}
	public void setRazao(int razao) {
		this.razao = razao;
	}
	
	
	//M�todos construtor
	
	public Matematica ( int a, int b, double soma, int tamanho, int a1, int n, int razao) {
		this.a = a;
		this.b = b;
		this.soma = soma;
		this.tamanho = tamanho;
		this.a1 = a1;
		this.n = n;
		this.razao = razao;
	}
	

	public static int subtracao (int a, int b) {
		if (a>=b)
		{
			return a - b;
		}
		else 
		{
			return b - a;
		}
	}
	
	public static double mediaAritmetica( double soma,int tamanho) {
		return soma/tamanho;
	}
	
	public static double pa (int a1, int razao, int n) {
		return a1+(n-1)*razao;
	}
	

}
