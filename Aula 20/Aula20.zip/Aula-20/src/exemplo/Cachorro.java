package exemplo;

public class Cachorro extends Animal {

	//Atributos
	private String raca;
	
	//Metodo
	public Cachorro(String nome,String raca) {
		super(nome);
		this.raca = raca;
		
	}

	//GET
	public String getRaca() {
		return this.raca;
	}

	@Override
	public void emitirSom() {
		System.out.println("Cachorro latindo!");
		
	}
	
}
