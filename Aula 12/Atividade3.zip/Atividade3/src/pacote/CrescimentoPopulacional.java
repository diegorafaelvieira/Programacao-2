package pacote;

public class CrescimentoPopulacional {
	
	private double populacaoA;
	private double populacaoB;
	private double taxaA;
	private double taxaB;
	private double ca;
	private double cb;
	private double a;
	private double b;
	private double anos;
	
	
	//Contrutor
	public CrescimentoPopulacional(double pa, double ta,double pb, double tb) {
		populacaoA = pa;
		populacaoB = pb;
		taxaA = ta;
		taxaB = tb;
		ca = (populacaoA*taxaA)/100;
		cb = (populacaoB*taxaB)/100;
		a = a + populacaoA;
		b = b + populacaoB;
	}
	
	

	
	public int calculaAnos() {
		if(populacaoA >= populacaoB) {
			return 0;
		}
		if(taxaA <= taxaB) {
			return 0;
		}
		else {
			int anos = 0;
			while(a < b) {
				b = (b+cb);
				a = (a+ca);
				anos++;
			
			}
			return anos;
		}
	}
	
	public double getPopulacaoA() {
		return populacaoA;
	}
	public void setPopulacaoA(double populacaoA) {
		this.populacaoA = populacaoA;
	}
	public double getPopulacaoB() {
		return populacaoB;
	}
	public void setPopulacaoB(double populacaoB) {
		this.populacaoB = populacaoB;
	}
	public double getTaxaA() {
		return taxaA;
	}
	public void setTaxaA(double taxaA) {
		this.taxaA = taxaA;
	}
	public double getTaxaB() {
		return taxaB;
	}
	public void setTaxaB(double taxaB) {
		this.taxaB = taxaB;
	}
	
	public double getAnos() {
		return anos;
	}

	public void setAnos(double anos) {
		this.anos = anos;
	}


	public void Imprimi() {
		System.out.println();
		System.out.println("A cidade A, tem "+getPopulacaoA()+" habitantes com uma taxa de crescimento de "+getTaxaA()+"  % anual");
		System.out.println("A cidade B, tem "+getPopulacaoB()+" habitantes com uma taxa de crescimento de "+getTaxaB()+"  % anual");
		System.out.println(calculaAnos()+ " anos");
		
	}

	
}

