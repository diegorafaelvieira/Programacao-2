package exercicio3;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner leitor = new Scanner(System.in);
		System.out.print("Digite uma frase:");
		String f = leitor.nextLine();
		System.out.println(f);
		
		
		char[] f1 = f.toCharArray();
		
		for (int i = 0; i < f1.length; i++) {
			if(f1[i] == 'a' || f1[i] == 'A') {
			   f1[i] = '*';
			   System.out.print(f1[i]);
		} else {
			System.out.print(f1[i]);
		}
		
		
	  }
		leitor.close();
	}	

}
