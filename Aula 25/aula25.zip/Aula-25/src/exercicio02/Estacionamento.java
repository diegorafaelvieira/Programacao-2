package exercicio02;


public class Estacionamento {
	private String entrada;
	private String saida;
	private Carro carro;
	
	
	//construtor
	public Estacionamento(String entrada, String saida, Carro carro) {
		this.entrada = entrada;
		this.saida = saida;
		this.carro = carro;
	}

	//GET e SET
	public String getEntrada() {
		return entrada;
	}


	public void setEntrada(String entrada) {
		this.entrada = entrada;
	}


	public String getSaida() {
		return saida;
	}


	public void setSaida(String saida) {
		this.saida = saida;
	}


	public Carro getCarro() {
		return carro;
	}


	public void setCarro(Carro carro) {
		this.carro = carro;
	}
	
	//Imprimir
	public void imprimiEstacionamento() {
		getCarro().imprimiCarro();
		System.out.println("Entrada: "+this.entrada+"\nSa�da: "+this.saida+" ");
		System.out.println();
	}
}