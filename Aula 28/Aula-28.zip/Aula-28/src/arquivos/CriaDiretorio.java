package arquivos;

import java.io.File;

public class CriaDiretorio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File dir = new File("Registro");
		//Clicar selecionando o projeto
		//criar file  
		dir.mkdir();
		
		//deletar file
		//dir.delete();
		
		File subdir = new File("Registro/Financeiros");
		//Clicar selecionando o projeto
		//criar file  
		subdir.mkdir();
		
		
		
		
	}

}
