package exemplos;

public class TesteArray {

	public static void main(String[] args) {
		int[] idades = new int [4];
		idades[0] = 17;
		idades[1] = 81;
		idades[2] = 12;
		idades[3] = 33;
		
		for (int i = 0; i < idades.length; i++) {
			System.out.print(idades[i] + " ");
		}

	}

}
