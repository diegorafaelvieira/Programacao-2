package exemplos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

public class MinhaApp1 {

	private JFrame frmMinhaaplicacao;
	private JTextField nomeTF;
	private JTextArea nomesTA;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MinhaApp1 window = new MinhaApp1();
					window.frmMinhaaplicacao.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MinhaApp1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMinhaaplicacao = new JFrame();
		frmMinhaaplicacao.getContentPane().setBackground(new Color(255, 0, 0));
		frmMinhaaplicacao.getContentPane().setLayout(null);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNome.setForeground(Color.YELLOW);
		lblNome.setBounds(10, 11, 102, 14);
		frmMinhaaplicacao.getContentPane().add(lblNome);
		
		nomeTF = new JTextField();
		nomeTF.setBounds(10, 36, 242, 20);
		frmMinhaaplicacao.getContentPane().add(nomeTF);
		nomeTF.setColumns(10);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				// Aqui vai o c�digo que sera executado quando o bot�o for clicado
			
				String t = nomeTF.getText();
				
				nomesTA.append(t + "\n");  //append vai acrescentando toda a palavra digitada
				//nomesTA.setText(t + "\n");   //setText apenas mostra uma palavra por vez
			}
		});
		btnOk.setBounds(163, 227, 89, 23);
		frmMinhaaplicacao.getContentPane().add(btnOk);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 133, 242, 83);
		frmMinhaaplicacao.getContentPane().add(scrollPane);
		
		nomesTA = new JTextArea();
		scrollPane.setViewportView(nomesTA);
		nomesTA.setBackground(Color.GREEN);
		frmMinhaaplicacao.setTitle("MinhaAplicacao");
		frmMinhaaplicacao.setBounds(100, 100, 300, 300);
		frmMinhaaplicacao.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
