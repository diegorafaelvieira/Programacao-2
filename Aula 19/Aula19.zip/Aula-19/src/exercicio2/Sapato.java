package exercicio2;

public class Sapato extends Produto{

	private int tamanho;
	
	//Construtor
	public Sapato(String nome, double valor, int tamanho) {
		super(nome,valor);
		this.tamanho = tamanho;
	}
	
	public void imprimir() {
		super.Imprimir();
		System.out.println("Tamanho: " + this.tamanho);	
	}

	//GET e SET
	public int getTamanho() {
		return tamanho;
	}

	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}
	
	
}
