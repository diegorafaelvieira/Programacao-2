package exemplos;

public class Contador {
	 
	// static = atributo de classe
	public static int numero = 0;

	
	
	//Criar um construtor que faz a contagem de objetos criados
	
	public Contador() {
		numero ++;
	}
	
	
	
	

}
