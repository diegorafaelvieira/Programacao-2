package exercicio1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CriaArquivoEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File arquivo= new File("Registro/nomes.txt");
		try {
			arquivo.createNewFile();
			//O true indica que o conteudo do arquivo deve ser mantido
			FileWriter escritor = new FileWriter(arquivo,true);     //false só deixa o print 1x
			
			
			BufferedWriter buffer = new  BufferedWriter(escritor);
			
			
			
			
			//ATENÇÃO Não esquecer de fechar
			buffer.close();
			escritor.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}	