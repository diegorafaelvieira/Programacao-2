package exemplos2;

public class Cidade {
	public String nome;
	public int populacao;
	public String estado;
}
