package exercicios;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		/*
		 * 1. Crie um sistema que leia do teclado o nome de 5 alunos e 3 notas de avalia��es.
		Armazene o nome dos alunos em um array chamado nomes.
		Por exemplo, em nomes[0] voc� armazenar� o nome do primeiro aluno.
		Armazene as notas em um array chamado notas com duas dimens�es.
		Por exemplo, em notas[1][2] voc� armazenar� a nota da avalia��o 2 do aluno 1.
		Calcule a m�dia de cada aluno, e logo ap�s imprima o nome do aluno e a sua respectiva m�dia.
		Finalmente, calcule a m�dia da turma em cada avalia��o.

		 */
		
		Scanner leitor = new Scanner(System.in);
		
		String [] nomes = new String [5];
		
		double [][]  notas = new double [3][5];
		
		double soma = 0, media;
	
		
		for (int i = 0 ; i <= 4 ; i++) {

			System.out.print("Informe o nome do aluno:");
			nomes[i] =  new Scanner(System.in).nextLine();
			
			System.out.print("Informe a 1� nota:");
			notas[i] =  new Scanner(System.in).nextDouble();
			System.out.print("Informe a 2� nota:");
			notas[i] =  new Scanner(System.in).nextDouble();
			System.out.print("Informe a 3� nota:");
			notas[i] =  new Scanner(System.in).nextDouble();
			soma = soma + notas[i];
			
			System.out.println(notas.length);
			System.out.println(notas[0].length);
			
			}
		
		/*for (int i = 0; i < notas.length; i++) {
			
			System.out.print("Informe a 1� nota do aluno:");
			notas[i] =  leitor.nextLine();
			System.out.print("Informe a 2� nota do aluno:");
			notas[i] =  leitor.nextLine();
			System.out.print("Informe a 3� nota do aluno:");
			notas[i] =  leitor.nextLine();
		}*/
		
		
		}
		
		//////tirei o notas daqui
		
		/*for (int j = 0; j < notas.length; j++) {
			System.out.print("Informe a nota (0 at� 10) do aluno:");
				notas[j] = leitor.nextDouble();
				System.out.println("Nota informada:"+notas[j]);
		}
		*/
		
		
		
		
				
		
		
}	
	


